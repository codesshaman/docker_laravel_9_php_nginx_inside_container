<?php

namespace App\Http\Resources;

use App\Models\Groups;
use App\Models\Message;
use App\Models\User;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;
use Illuminate\Http\Resources\Json\JsonResource;

class MessageResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */

    private static $data;

    public function toArray($request)
    {
        if (self::$data == 'allMessages') {
            // if ($this->read_at) {
            return [
                'receiver_id' =>    $this->user_id,
                'user_id' =>   $this->receiver_id,
                'receiver_name' => ($this->receiver_id == auth()->id()) ? ($this->user_id == auth()->id()  ? 'Я' : $this->user_sender->name)  : $this->users->name,
                'unread_msg' => $this->unread_msg($this),
                // 'read_at' => $this->read_at,

            ];
            // } else return   null;
        }
        if (self::$data == 'PrivetMsgSocket') {
            return [
                'id' => $this->id,
                'content' => ($this->is_deleted == true) ? 'deleted message' : $this->content,
                'user_id' => $this->receiver_id,
                'sender_name' => ($this->receiver_id == auth()->id()) ? 'Я' : $this->user_sender->name,
                'receiver_id' => $this->user_id,
                'receiver_name' => (!$this->is_group) ? ($this->user_id == auth()->id()  ? 'Я' : $this->users->name) : $this->groups->group_name,
                'type' => $this->message_type,
                'send_timestamp' => $this->created_at->getTimestamp(),
                'reading_id' => $this->reading_id,
                'read_at' => $this->read_at ? $this->read_at->diffForHumans() : null,

            ];
        } else
        if (self::$data == 'messageGroup') {
            return [
                'id' => $this->id,
                'content' => ($this->is_deleted == true) ? 'deleted message' : $this->content,
                'user_id' =>  $this->user_id,
                'sender_name' =>   $this->user_sender->name,
                'receiver_id' => $this->receiver_id,
                'receiver_name' =>  $this->groups->group_name,
                'type' => $this->message_type,
                'send_timestamp' => $this->created_at->getTimestamp(),
                'reading_id' => $this->reading_id,
                'read_at' => $this->read_at ? $this->read_at->diffForHumans() : null,
            ];
        } else
            return [
                'id' => $this->id,
                'content' => ($this->is_deleted == true) ? 'deleted message' : $this->content,
                'user_id' => $this->user_id,
                'sender_name' => ($this->user_id == auth()->id()) ? 'Я' : $this->user_sender->name,
                'receiver_id' => $this->receiver_id,
                'receiver_name' => (!$this->is_group) ? ($this->receiver_id == auth()->id()  ? 'Я' : $this->users->name) : $this->groups->group_name,
                'type' => $this->message_type,
                'send_timestamp' => $this->created_at->getTimestamp(),
                'read_at' => $this->read_at ? $this->read_at->diffForHumans() : null,
            ];
    }
    private function unread_msg($_this)
    {
        return Message::Where("read_at", null)->Where("user_id", $_this->user_id)->Where("receiver_id", auth()->id())->count();
    }
    //custom function that returns collection type
    public static function customCollection($resource, $data): AnonymousResourceCollection
    {
        //you can add as many params as you want.
        self::$data = $data;
        return parent::collection($resource);
    }
}
