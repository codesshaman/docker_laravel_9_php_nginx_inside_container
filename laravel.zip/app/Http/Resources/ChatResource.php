<?php

namespace App\Http\Resources;

use App\Models\Session;
use Illuminate\Http\Resources\Json\JsonResource;

class ChatResource extends JsonResource
{

    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'message' => $this->message['content'],
            'type' => $this->type,
            'read_at' => $this->read_at_timing($this),    
            // 'user_id' => Session::where('id', $this->id)->first('user2_id'),
            'user_id' =>$this->user_id,
            'send_at' => $this->created_at->diffForHumans()
        ];
    }
    private function read_at_timing($_this)
    {
        $read_at = $_this->type == 0 ? $_this->read_at : null;
        return $read_at ? $read_at->diffForHumans() : null;
    }
}
