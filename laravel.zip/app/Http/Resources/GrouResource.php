<?php

namespace App\Http\Resources;

use App\Models\Session;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class GrouResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'group_name' => $this->group_name,
            'user_id' => $this->user_id,
            'user_name' => User::find($this->user_id)->name, 
            'users_count' => $this->user_groups_count,
            'created_at' => $this->created_at,
        ];
    }
}
