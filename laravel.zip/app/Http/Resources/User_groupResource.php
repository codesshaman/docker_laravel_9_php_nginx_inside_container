<?php

namespace App\Http\Resources;

use App\Models\Groups;
use App\Models\Session;
use App\Models\User;
use Illuminate\Http\Resources\Json\JsonResource;

class User_groupResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'group_name' => Groups::find($this->group_id)->group_name,
            'group_id' => $this->group_id,
            'user_id' => $this->user_id,
            'user_name' => User::find($this->user_id)->name,
            'join_at' => $this->created_at,
        ];
    }
}
