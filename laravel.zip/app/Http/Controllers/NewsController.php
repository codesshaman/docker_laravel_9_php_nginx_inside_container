<?php

namespace App\Http\Controllers;

use App\Events\NotificationNews;
use Illuminate\Http\Request;
use App\Models\News;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

class NewsController extends Controller
{   
    
    public function allNews(){
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
            case 67274:
            case 76399:
                $news = DB::table('news')->orderby('date', 'desc')->take(300)->get();
                foreach ($news as $one_news){
                    $time = $one_news -> date; 
                    $time = date('d-m-Y H:i', $time);
                    $one_news -> date = $time;
                    unset($one_news -> text_ws);
                }
                return response()->json($news, 200, ['Content-type'=>'application/json;charset=utf-8'],JSON_UNESCAPED_UNICODE);
                break;
            case 67270:
                return response()->json('Недостаточно прав доступа.', 403);           
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }
   
    public function addNews(Request $request){
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
                #Создание новой новости
                News::newNews($request -> title, $request -> text_news,'Администратор добавил новость.');
                return response()->json('Новость успешно добавлена!', 201);   
                break;
            
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);           
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

}
