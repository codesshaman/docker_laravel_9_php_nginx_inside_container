<?php

namespace App\Http\Controllers;

use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

class EmailController extends Controller
{
    public function forgotPassword(Request $request)
    {
        $request->validate(['email' => 'required|email']);

        $user = DB::table('users')->where('email', $request->email)->first();
        if (!$user)
            return response()->json("Пользователя с таким e-mail нет в системе", 404);

        $status = Password::sendResetLink(
            $request->only('email')
        );

        return response()->json($status === Password::RESET_LINK_SENT
            ? ["message" => "Письмо было отправлено на вашу почту", "status" => 200]
            : ["message" => "Что-то не так", "status" => 500, "error" => __($status)], 200);
    }

    public function resetPassword(Request $request)
    {
        if (empty($request->password))
            return view('auth.reset-password', ['token' => $request->token, 'email' => $request->email])->withErrors(null);

        $validator = Validator::make($request->all(), [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:8|confirmed',
        ]);



        if ($validator->fails()) {
            return view('auth.reset-password', ['token' => $request->token, 'email' => $request->email])->withErrors($validator);
        } else {

            $status = Password::reset(
                $request->only('email', 'password', 'password_confirmation', 'token'),
                function ($user, $password) {
                    $user->forceFill([
                        'password' => Hash::make($password)
                    ])->setRememberToken(Str::random(60));

                    $user->save();

                    event(new PasswordReset($user));
                }
            );
            switch ($status) {
                case "passwords.token":
                    return redirect('/resetPasswordLinkError');
                case "passwords.reset":
                    return redirect('/resetPasswordSuccess');
                default:
                    return redirect('/resetPasswordLinkError');
            }
        }
    }
}
