<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class DepartmentController extends Controller
{
    
    public function AllDepartment()
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:                                                     //Админ (Вадим)
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                $departments = DB::table('departments')->select('id', 'name')->get();
                // $departments = (array)$departments;
                // $dep = [];
                // foreach ($departments as $department) {
                //     array_push($dep, $department);
                // }
                // array_push($dep, ["id" =>'add', "name" => 'add']);

                return response()->json($departments, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
            case 93260:                                                     //Супер Админ (главный босс Настя)
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }
    public function oneDepartment($id)
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                //$department = DB::table('departments')->where('id', $id)->get();
                $department = Department::find($id);

                $staff = DB::table('users')->where('role', 76399)->select('id', 'name', 'department')->orderby('name', 'asc')->get();
                $supervisors = DB::table('users')->whereIn('role', [67274, 93260, 93160])->select('id', 'name')->orderby('name', 'asc')->get();
                $staff_dep = [];
                $staff_no_dep = [];
                $supervisor_no_dep = [];

                foreach ($staff as $worker) {
                    if ($worker->department == $department->id) {
                        array_push($staff_dep, $worker);
                    } elseif ($worker->department == null) {
                        array_push($staff_no_dep, $worker);
                    }
                }

                foreach ($supervisors as $supervisor) {
                    if ($supervisor->id == $department->supervisor) {
                        $supervisor_dep = $supervisor;
                    } else {
                        array_push($supervisor_no_dep, $supervisor);
                    }
                }

                $department->staff = $staff_dep;
                $department->supervisor =  $supervisor_dep;
                $department->staff_no_dep =  $staff_no_dep;
                $department->supervisor_no_dep =  $supervisor_no_dep;

                //$all_staff = ["staff" => $staff, "supervisors" => $supervisors];

                return response()->json($department, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
            case 93260:                                                     //Супер Админ (главный босс Настя)
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function DeleteStaff($id, Request $request)
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                //$department = DB::table('departments')->where('id', $id)->get();
                if ($request -> has('supervisor')){
                    $department = Department::find($id);
                    $department->supervisor = $request->supervisor;
                    $department -> save();

                    $sup_id = $request->supervisor;
                    $user_sup = User::find($sup_id);
                    $user_sup->department = $id;
                    $user_sup->save();
                }
                if ($request -> has('staff')){
                    $staff_id = $request->staff;
                    if (is_array($staff_id)) {
                        $staff = DB::table('users')->whereIn('id', $staff_id)->update(['department' => null]);
                    } else {
                        $staff = DB::table('users')->where('id', $staff_id)->update(['department' => null]);
                    }
                }

                if ($request -> has('supervisor') || $request -> has('staff')){
                    return response()->json('Отдел изменен.', 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                } else {
                    return response()->json('Изменений нет.', 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
            case 93260:                                                     //Супер Админ (главный босс Настя)
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function AddStaff($id, Request $request)
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                //$department = DB::table('departments')->where('id', $id)->get();
                if ($request -> has('name')){
                    $department = Department::find($id);
                    $department->name = $request->name;
                    $department -> save();

                    
                }
                if ($request -> has('staff')){
                    $staff_id = $request->staff;
                    if (is_array($staff_id)) {
                        $staff = DB::table('users')->whereIn('id', $staff_id)->update(['department' => $id]);
                    } else {
                        $staff = DB::table('users')->where('id', $staff_id)->update(['department' => $id]);
                    }
                }
                if ($request -> has('name') || $request -> has('staff')){
                    return response()->json('Отдел изменен.', 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                } else {
                    return response()->json('Изменений нет.', 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
            case 93260:                                                     //Супер Админ (главный босс Настя)
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function CreateDepartment (Request $request){
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:                                                     //Админ (Вадим) 
                if ($request->has('staff')) {
                    if (!empty($request->staff)) {
                        $department = new Department();
                        $department->name = $request->name;
                        $department->supervisor = $request->supervisor;
                        $department->save();
                        $department_id = $department->id;
                        $sup_id = $department->supervisor;
                        $user_sup = User::find($sup_id);
                        $user_sup->department = $department_id;
                        $user_sup->save();
                        foreach ($request->staff as $one_staff) {
                            $user = User::find($one_staff);
                            $user->department = $department_id;
                            $user->save();
                        }
                        return response()->json('Отдел создан.', 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                    } else {
                        $obgect = ['message' => "Вы не можете создать отдел без сотрудников.", "status" => 404];
                        return response()->json($obgect, 404, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                    }
                } else {
                    $obgect = ['message' => "Вы не можете создать отдел без сотрудников.", "status" => 404];
                    return response()->json($obgect, 404, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function FormForCreateDepartment (){
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:                                                     //Админ (Вадим)
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                $staff = DB::table('users')->where('role', 76399)->select('id', 'name')->orderby('name', 'asc')->get();
                $supervisors = DB::table('users')->whereIn('role', [67274, 93260, 93160])->select('id', 'name')->orderby('name', 'asc')->get();
                $all_staff = ["staff" => $staff, "supervisors" => $supervisors];

                return response()->json($all_staff, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }
}
