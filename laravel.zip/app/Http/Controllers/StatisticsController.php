<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\QualitiesMonth;
use App\Models\Quality;
use App\Models\QualityDepartment;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class StatisticsController extends Controller
{
    protected $constructor_table;
    public function __construct()
    {
        $constructor_table = [];
        $columns_name = Schema::getColumnListing('qualities');
        foreach ($columns_name as $name) {
            array_push(
                $constructor_table,
                [
                    "title" => $name,
                    "type" => Schema::getColumnType('qualities', $name)
                ]
            );
        }
        $this->constructor_table = $constructor_table;
    }

    private function pie_dashboard($name, $center, $data)
    {
        $dashboard = [
            "chart" => [
                "type" => 'pie',
                "renderTo" => 'atmospheric-composition',
            ],
            "credits" => [
                "enabled" => false
            ],
            "title" => [
                "verticalAlign" => 'middle',
                "horizontalAlign" => 'middle',
                "floating" => false,
                "text" => $center,
                "style" => [
                    "fontSize" => '15px',
                ],
            ],
            "tooltip" => [
                "pointFormat" => '{series.name}: <b>{point.x} руб</b>'
            ],
            "plotOptions" => [
                "pie" => [
                    "dataLabels" => [
                        "enabled" =>  false
                    ],
                    "innerSize" => '50%',
                    "showInLegend" => true,
                ],
            ],
            // "legend" => [
            "legend" => [
                "enabled" => true,
                "align" => "left",
                "verticalAlign" => "center",
                "layout" => "vertical",
                "itemStyle" => [
                    "align" => "right",
                    "color" => "rgba(96,125,139,1.00)",
                    "fontFamily" => "Open Sans",
                    "fontSize" => "18px",
                    "fontWeight" => "normal",
                    "fontStyle" => "normal"
                ],
                "itemMarginTop" => 1.5
                // ]
            ],
            "series" => [[
                "name" => $name,
                "data" => $data
            ]],
        ];
        return ($dashboard);
    }

    private function group_column_dashboard($title, $categories, $series)
    {
        $dashboard = [
            "chart" => [
                "type" => 'column',
            ],
            "title" => [
                "text" => $title,
            ],
            "xAxis" => [
                "categories" => $categories,
                "crosshair" => true,
            ],
            "credits" => [
                "enabled" => false
            ],
            "yAxis" => [
                "min" => 0,
                //"max" => 100,
                "title" => [
                    "text" => 'Процент выполнения плана',
                ]
            ],
            "tooltip" => [
                "headerFormat" => '<span style="font-size:10px">{point.key}</span><table></br>',
                // "pointFormat" => 
                //     " \'<tr><td style=\"color:{series.color};padding:0\">{series.name}: </td>\' +
                //     \'<td style=\"padding:0\"><b>{point.y:.1f} %</b></td></tr>\' ",
                "footerFormat" => '</table>',
                "shared" => true,
                'useHTML' => true,
            ],
            "plotOptions" => [
                "column" => [
                    "pointPadding" => 0.2,
                    "borderWidth" => 0,
                ],
            ],
            "series" => $series
        ];
        return ($dashboard);
    }

    private function column_dashboard($title, $name, $data)
    {
        $dashboard = [
            "chart" => [
                "type" => 'column',
            ],
            "credits" => [
                "enabled" => false
            ],
            "title" => [
                "align" => 'left',
                "text" => $title,
            ],
            "tooltip" => [
                //"pointFormat" => '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}%</b><br/>',
                "headerFormat" => '<span style="font-size:11px">{series.name}</span><br>',
                "pointFormat" => 'План: <b> {point.plan}</b> руб<br/> Выполнено: <b> {point.sum}</b> руб<br/>',
            ],
            "plotOptions" => [
                'series' => [
                    'borderWidth' => 0,
                    'dataLabels' => [
                        'enabled' => true,
                        'format' =>  '{point.y:.1f}%'
                    ]
                ]
            ],
            "legend" => [
                "enabled" => false,
            ],
            "series" => [[
                'name' => $name,
                'colorByPoint' =>  true,
                'data' =>  $data
            ]],
            // 'subtitle' => [
            //     'align' => 'left',
            //     'text' => 'Click the columns to view versions. Source: <a href="http://statcounter.com" target="_blank">statcounter.com</a>'
            // ],
            'accessibility' => [
                'announceNewData' => [
                    'enabled' => true
                ]
            ],
            'xAxis' => [
                'type' => 'category'
            ],
            'yAxis' => [
                'title' => [
                    'text' => null
                ]

            ],
        ];
        return ($dashboard);
    }

    private function bar_dashboard($title, $done)
    {
        $dashboard = [
            "chart" => [
                "type" => 'bar',
            ],
            "credits" => [
                "enabled" => false
            ],

            "title" => [
                // "align" => 'left',
                "text" => $title,
            ],

            "tooltip" => [
                //"pointFormat" => '<span style="color:{point.color}">{point.name}</span>: <b>{point.y}%</b><br/>',
                "headerFormat" => '<span style="font-size:11px">{series.name}</span><br>',
                "pointFormat" => '<b>{point.y}%</b><br/>',
            ],
            "plotOptions" => [
                'series' => [
                    'stacking' => 'normal'
                ]
            ],
            "legend" => [
                "enabled" => false,
            ],
            "series" => [
                [
                    'name' => 'Осталось',
                    'data' => [100 - $done]
                ], [
                    'name' => 'Выполнено',
                    'data' => [$done]
                ]
            ],
            'xAxis' => [
                'visible' => false,
                'title' => [
                    'text' => null
                ],
                //'categories' => ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
            ],
            'yAxis' => [
                'visible' => false,
                'max' => 100,
                'title' => [
                    'text' => null
                ]

            ],
        ];
        return ($dashboard);
    }

    private function date_calculation($request)
    {
        if ($request->has("date")) {
            $time = $request->date;
            if (strlen($time) < 3) {
                $time = $time + 1;
                $year = date('Y');
                $start = strtotime($year . '-' . $time . '-01');
                $month_end = date('t', $start);
                $finish = strtotime($year . '-' . $time . '-' . $month_end);
            } else {
                $start = strtotime(mb_strcut($time, 0, 7) . '-01');
                $month_end = date('t', strtotime(mb_strcut($time, 8, 7) . '-01'));
                $finish = strtotime(mb_strcut($time, 8, 7) . '-' . $month_end);
            }
            //$dates = [$start, $finish];
        } else {
            $time = Carbon::today()->timezone('Europe/Moscow');
            $start = strtotime(Carbon::yesterday()->timezone('Europe/Moscow'));
            $finish = strtotime(Carbon::tomorrow()->timezone('Europe/Moscow'));
            // $month = date('m');
            // $year = date('Y');
            // $start_month = strtotime($year . '-' . $month . '-01');
            // $dates = [$start, $finish, $start_month];
        }
        $month = date('m');
        $year = date('Y');
        $start_month = strtotime($year . '-' . $month . '-01');
        $dates = [$start, $finish, $start_month];
        return ($dates);
    }

    public function dashboard(Request $request)
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 93160:                                                     //Админ (Вадим)
                $dates = $this->date_calculation($request);
                $start = $dates[0];
                $finish = $dates[1];
                if ($request->has("department")) {                                                                                                //отдел
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                    $staff_department = DB::table('users')->where('role', 76399)->where('department', $request['department'])->select('id', 'name')->orderby('name', 'asc')->get();
                    $departments = DB::table('departments')->select('id', 'name')->get();
                    $staff_id = [];
                    foreach ($staff_department as $staff) {
                        array_push($staff_id, $staff->id);
                    }

                    $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // switch (count($dates)) {
                    //     case 3:
                            $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();

                    //         break;
                    //     default:
                    //         $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // }
                    $count = $staff_department->count();

                    //переменные для 1
                    $departments_result = [];
                    $staff_name = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    //для таблиц
                    $user_result = [];

                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                    foreach ($result_staff as $one_result) {
                        $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                    }
                    foreach ($result_staff_months as $one_result) {
                        $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                    }
                    //4
                    if ($sum_plan_all == 0) {
                        $done = 0;
                    } else {
                        $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                    }

                    $calls = 0;
                    $long_calls = 0;
                    $balances = 0;
                    $good_balances = 0;
                    $sum_issued_bg = 0;
                    $sum_plan = 0;

                    for ($i = 0; $i < $count; $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                       
                        $id =  $staff_id[$i];
                        foreach ($result_staff as $one_result) {
                            if ($one_result->user_id == $id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                                
                            }
                        }
                        foreach ($result_staff_months as $one_result) {
                            if ($one_result->user_id == $id) {
                                $sum_plan = $one_result->sum_plan + $sum_plan;
                            }
                        }
                        if ($sum_plan == 0) {
                            $sum_bg = 0;
                        } else {
                            $sum_bg = floor(($sum_issued_bg * 100) / $sum_plan); 
                        }
                        

                        $name = $staff_department[$i]->name;
                        //1
                        array_push($departments_result, [$calls,  $long_calls, $balances, $good_balances]);
                        array_push($staff_name, $name);
                        //2
                        if ($sum_issued_bg_all == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                        }
                        array_push(
                            $data_pie,
                            [
                                "name" => $name,
                                'y' => $y,
                                'color' => '#' . dechex(rand(0, 10000000)),
                                'x' => $sum_issued_bg
                            ]
                        );
                        //3
                        if ($sum_plan == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_plan);
                        }
                        array_push(
                            $data_column,
                            [
                                "name" => $name,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                        //таблица
                        array_push($user_result, [
                            "id" => $id,
                            "name" => $name,
                            "calls" => $calls,
                            "long_calls" => $long_calls,
                            "balances" => $balances,
                            "good_balances" => $good_balances,
                            "sum_issued_bg" => $sum_issued_bg,
                            "sum_bg" => $sum_bg,
                            "sum_plan" =>  $sum_plan
                        ]);
                    }

                    //1
                    for ($i = 0; $i < 4; $i++) {
                        $data = [];
                        foreach ($departments_result as $one_result) {
                            array_push($data, $one_result[$i]);
                        }
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    }
                    $group_column_dashboard = $this->group_column_dashboard(' ', $staff_name, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => $departments,
                        "staff" => $staff_department
                    ];
                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                } else if ($request->has("user_id")) {                                                                                        //один человек
                    $user_id =  $request["user_id"];
                    $week = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                    $department_id = DB::table('users')->where('id', $user_id)->select('department')->orderby('name', 'asc')->get();
                    $department_id = $department_id[0]->department;
                    $staff_department = DB::table('users')->where('role', 76399)->where('department', $department_id)->select('id', 'name')->orderby('name', 'asc')->get();
                    $departments = DB::table('departments')->select('id', 'name')->get();
                    $staff_id = [];
                    foreach ($staff_department as $staff) {
                        array_push($staff_id, $staff->id);
                    }

                    $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // switch (count($dates)) {
                    //     case 3:
                            $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();

                    //         break;
                    //     default:
                    //         $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // }

                    $count = $staff_department->count();

                    //переменные для 1
                    $one_staff_result = [];
                    $staff_date = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    //для таблиц
                    $user_result = [];

                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                    foreach ($result_staff as $one_result) {
                        $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                    }
                    foreach ($result_staff_months as $one_result) {
                        $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                    }
                    //4
                    if ($sum_plan_all == 0) {
                        $done = 0;
                    } else {
                        $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                    }
                    for ($i = 0; $i < $count; $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                        $id =  $staff_id[$i];
                        foreach ($result_staff as $one_result) {
                            if ($one_result->user_id == $id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                                if ($id == $user_id) {
                                    $day = $one_result->date;
                                    $day_week = date('w', $day);
                                    $day = $week[$day_week] . date(' d.m.Y', $day);
                                    array_push($staff_date, $day);
                                }
                            }
                        }
                        foreach ($result_staff_months as $one_result) {
                            if ($one_result->user_id == $id) {
                                $sum_plan = $one_result->sum_plan + $sum_plan;
                            }
                        }
                        if ($sum_plan == 0) {
                            $sum_bg = 0;
                        } else {
                            $sum_bg = floor(($sum_issued_bg * 100) / $sum_plan); 
                        }
                        
                        $name = $staff_department[$i]->name;
                        //1
                        array_push($one_staff_result, [$calls,  $long_calls, $balances, $good_balances]);

                        //2
                        if ($sum_issued_bg_all == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                        }
                        array_push(
                            $data_pie,
                            [
                                "name" => $name,
                                'y' => $y,
                                'color' => '#' . dechex(rand(0, 10000000)),
                                'x' => $sum_issued_bg
                            ]
                        );
                        //3
                        if ($sum_plan == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_plan);
                        }
                        array_push(
                            $data_column,
                            [
                                "name" => $name,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                        array_push($user_result, [
                            "id" => $id,
                            "name" => $name,
                            "calls" => $calls,
                            "long_calls" => $long_calls,
                            "balances" => $balances,
                            "good_balances" => $good_balances,
                            "sum_issued_bg" => $sum_issued_bg,
                            "sum_bg" => $sum_bg,
                            "sum_plan" =>  $sum_plan
                        ]);
                    }
                    //1
                    
                    for ($i = 0; $i < 4; $i++) {
                        $data = [];
                        foreach ($one_staff_result as $one_result) {
                            array_push($data, $one_result[$i]);
                        }
                      
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    }
                    //dump($series);
                    $group_column_dashboard = $this->group_column_dashboard(' ', $staff_date, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => $departments,
                        "staff" => $staff_department

                    ];

                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                } else {                                                                                                                         //вся компания
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                    $result = DB::table('quality_departments')->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    $result_staff = DB::table('qualities')->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // switch (count($dates)) {
                    //     case 3:
                            $result_staff_months = DB::table('qualities_months')->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();
                    //         break;
                    //     default:
                    //         $result_staff_months = DB::table('qualities_months')->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // }
                    $departments_id = DB::table('departments')->select('id', 'name')->get();
                    //$users = DB::table('users')->whereIn('role', [67274, 76399])->where('department', '!=', null)->select('id', 'name', 'department')->get();
                    $users = DB::table('users')->where('role', 76399)->where('department', '!=', null)->select('id', 'name', 'department')->orderby('name', 'asc')->get();

                    $count_dep = $departments_id->count();
                    $count_staff =  $users->count();
                    //переменные для 1
                    $departments_result = [];
                    $categories = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    $user_result = [];

                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                    foreach ($result_staff_months as $one_result) {
                        $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                    }
                    foreach ($result as $one_result) {
                        $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                    }
                    //4
                    if ($sum_plan_all == 0) {
                        $done = 0;
                    } else {
                        $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                    }
                    for ($i = 0; $i < $count_dep; $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                        $id =  $departments_id[$i]->id;

                        foreach ($result as $one_result) {
                            if ($one_result->department_id == $id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                            }
                        }
                        $user_dep_id = [];
                        foreach ($users as $user) {
                            if ($user->department == $id) {
                                array_push($user_dep_id, $user->id);
                            }
                        }
                        
                        if (!empty($user_dep_id)){
                            
                            foreach ($result_staff_months as $one_result) {
                               
                                if (in_array($one_result->user_id, $user_dep_id)) {
                                    $sum_plan = $one_result->sum_plan + $sum_plan;
                                }
                            }
                        }
                        
                        

                        $department =  $departments_id[$i]->name;
                        //1
                        array_push($departments_result, [$calls,  $long_calls, $balances, $good_balances]);
                        array_push($categories, $department);
                        //2
                        if ($sum_issued_bg_all == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                        }
                        array_push(
                            $data_pie,
                            [
                                "name" => $department,
                                'y' => $y,
                                'color' => '#' . dechex(rand(0, 10000000)),
                                'x' => $sum_issued_bg
                            ]
                        );
                        //3
                        if ($sum_plan == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_plan);
                        }
                        array_push(
                            $data_column,
                            [
                                "name" => $department,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                    }
                    for ($i = 0; $i < $count_staff; $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                        $id =  $users[$i]->id;
                        foreach ($result_staff as $one_result) {
                            if ($one_result->user_id == $id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                            }
                        }

                        foreach ($result_staff_months as $one_result) {
                            if ($one_result->user_id == $id) {
                                $sum_plan = $one_result->sum_plan + $sum_plan;
                            }
                        }

                        if ($sum_plan == 0) {
                            $sum_bg = 0;
                        } else {
                            $sum_bg = floor(($sum_issued_bg * 100) / $sum_plan); 
                        }

                        $name =   $users[$i]->name;

                        array_push($user_result, [
                            "id" => $id,
                            "name" => $name,
                            "calls" => $calls,
                            "long_calls" => $long_calls,
                            "balances" => $balances,
                            "good_balances" => $good_balances,
                            "sum_issued_bg" => $sum_issued_bg,
                            "sum_bg" => $sum_bg,
                            "sum_plan" =>  $sum_plan
                        ]);
                    }


                    //1
                    for ($i = 0; $i < 4; $i++) {
                        $data = [];
                        foreach ($departments_result as $one_result) {
                            array_push($data, $one_result[$i]);
                        }
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    }

                    $group_column_dashboard = $this->group_column_dashboard(' ', $categories, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => $departments_id,
                        "staff" => $users

                    ];
                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 67274: //Рук отдела
                $dates = $this->date_calculation($request);
                $start = $dates[0];
                $finish = $dates[1];
                $department_id = auth()->user()->department;
                if (!empty($department_id)) {
                    if ($request->has("user_id")) {                                                                                        //один человек
                        $user_id =  $request["user_id"];
                        $week = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
                        $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                        $staff_department = DB::table('users')->where('role', 76399)->where('department', $department_id)->select('id', 'name')->orderby('name', 'asc')->get();
                        $staff_id = [];
                        foreach ($staff_department as $staff) {
                            array_push($staff_id, $staff->id);
                        }

                        $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                        // switch (count($dates)) {
                        //     case 3:
                                $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();

                        //         break;
                        //     default:
                        //         $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                        // }

                        $count = $staff_department->count();

                        //переменные для 1
                        $one_staff_result = [];
                        $staff_date = [];
                        $series = [];
                        //переменные для 2
                        $data_pie = [];
                        //переменные для 3
                        $data_column = [];
                        $user_result = [];

                        //переменные для всех
                        $sum_issued_bg_all = 0;
                        $sum_plan_all = 0;
                        foreach ($result_staff as $one_result) {
                            $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                        }
                        foreach ($result_staff_months as $one_result) {
                            $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                        }
                        //4
                        if ($sum_plan_all == 0) {
                            $done = 0;
                        } else {
                            $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                        }
                        for ($i = 0; $i < $count; $i++) {
                            $calls = 0;
                            $long_calls = 0;
                            $balances = 0;
                            $good_balances = 0;
                            $sum_issued_bg = 0;
                            $sum_plan = 0;
                            $id =  $staff_id[$i];
                            foreach ($result_staff as $one_result) {
                                if ($one_result->user_id == $id) {
                                    $calls = $one_result->calls + $calls;
                                    $long_calls = $one_result->long_calls + $long_calls;
                                    $balances = $one_result->balances + $balances;
                                    $good_balances = $one_result->good_balances + $good_balances;
                                    $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                                    if ($id == $user_id) {
                                        $day = $one_result->date;
                                        $day_week = date('w', $day);
                                        $day = $week[$day_week] . date(' d.m.Y', $day);
                                        array_push($staff_date, $day);
                                    }
                                }
                            }
                            foreach ($result_staff_months as $one_result) {
                                if ($one_result->user_id == $id) {
                                    $sum_plan = $one_result->sum_plan + $sum_plan;
                                }
                            }
                            if ($sum_plan == 0) {
                                $sum_bg = 0;
                            } else {
                                $sum_bg = floor(($sum_issued_bg * 100) / $sum_plan); 
                            }
                            

                            $name = $staff_department[$i]->name;
                            //1
                            array_push($one_staff_result, [$calls,  $long_calls, $balances, $good_balances]);

                            //2
                            if ($sum_issued_bg_all == 0) {
                                $y = 0;
                            } else {
                                $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                            }
                            array_push(
                                $data_pie,
                                [
                                    "name" => $name,
                                    'y' => $y,
                                    'color' => '#' . dechex(rand(0, 10000000)),
                                    'x' => $sum_issued_bg
                                ]
                            );
                            //3
                            if ($sum_plan == 0) {
                                $y = 0;
                            } else {
                                $y = floor(($sum_issued_bg * 100) / $sum_plan);
                            }
                            array_push(
                                $data_column,
                                [
                                    "name" => $name,
                                    'y' => $y,
                                    'plan' => $sum_plan,
                                    'sum' => $sum_issued_bg,
                                ]
                            );

                            array_push($user_result, [
                                "id" => $id,
                                "name" => $name,
                                "calls" => $calls,
                                "long_calls" => $long_calls,
                                "balances" => $balances,
                                "good_balances" => $good_balances,
                                "sum_issued_bg" => $sum_issued_bg,
                                "sum_bg" => $sum_bg,
                                "sum_plan" =>  $sum_plan
                            ]);
                        }
                        //1
                        for ($i = 0; $i < 4; $i++) {
                            $data = [];
                            foreach ($one_staff_result as $one_result) {
                                array_push($data, $one_result[$i]);
                            }
                            array_push(
                                $series,
                                [
                                    "name" => $name_column[$i],
                                    "data" =>  $data,
                                ]
                            );
                        }

                        $group_column_dashboard = $this->group_column_dashboard(' ', $staff_date, $series);
                        $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                        $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                        $bar_dashboard = $this->bar_dashboard(' ', $done);
                        $dashboard = [
                            "group_column_dashboard" => $group_column_dashboard,
                            "pie_dashboard" => $pie_dashboard,
                            "column_dashboard" => $column_dashboard,
                            "bar_dashboard" => $bar_dashboard,
                            "table" => $user_result,
                            "departments" => null,
                            "staff" =>  $staff_department

                        ];

                        return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                    } else {    
                                                                                                                //отдел
                        $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                        $staff_department = DB::table('users')->where('role', 76399)->where('department',  $department_id)->select('id', 'name')->orderby('name', 'asc')->get();
                        $staff_id = [];
                        foreach ($staff_department as $staff) {
                            array_push($staff_id, $staff->id);
                        }

                        $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                        // switch (count($dates)) {
                        //     case 3:
                                $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();

                        //         break;
                        //     default:
                        //         $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                        // }

                        $count = $staff_department->count();

                        //переменные для 1
                        $departments_result = [];
                        $staff_name = [];
                        $series = [];
                        //переменные для 2
                        $data_pie = [];
                        //переменные для 3
                        $data_column = [];
                        $user_result = [];

                        //переменные для всех
                        $sum_issued_bg_all = 0;
                        $sum_plan_all = 0;
                        foreach ($result_staff as $one_result) {
                            $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                        }
                        foreach ($result_staff_months as $one_result) {
                            $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                        }
                        //4
                        if ($sum_plan_all == 0) {
                            $done = 0;
                        } else {
                            $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                        }

                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                        $sum_bg = 0;
                        for ($i = 0; $i < $count; $i++) {
                            $calls = 0;
                            $long_calls = 0;
                            $balances = 0;
                            $good_balances = 0;
                            $sum_issued_bg = 0;
                            $sum_plan = 0;
                            $id =  $staff_id[$i];
                            foreach ($result_staff as $one_result) {
                                if ($one_result->user_id == $id) {
                                    $calls = $one_result->calls + $calls;
                                    $long_calls = $one_result->long_calls + $long_calls;
                                    $balances = $one_result->balances + $balances;
                                    $good_balances = $one_result->good_balances + $good_balances;
                                    $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                                    $sum_bg = $one_result->sum_bg + $sum_bg;
                                }
                            }
                            foreach ($result_staff_months as $one_result) {
                                if ($one_result->user_id == $id) {
                                    $sum_plan = $one_result->sum_plan + $sum_plan;
                                }
                            }

                            $name = $staff_department[$i]->name;
                            //1
                            array_push($departments_result, [$calls,  $long_calls, $balances, $good_balances]);
                            array_push($staff_name, $name);
                            //2
                            if ($sum_issued_bg_all == 0) {
                                $y = 0;
                            } else {
                                $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                            }
                            array_push(
                                $data_pie,
                                [
                                    "name" => $name,
                                    'y' => $y,
                                    'color' => '#' . dechex(rand(0, 10000000)),
                                    'x' => $sum_issued_bg
                                ]
                            );
                            //3
                            if ($sum_plan == 0) {
                                $y = 0;
                            } else {
                                $y = floor(($sum_issued_bg * 100) / $sum_plan);
                            }
                            array_push(
                                $data_column,
                                [
                                    "name" => $name,
                                    'y' => $y,
                                    'plan' => $sum_plan,
                                    'sum' => $sum_issued_bg,
                                ]
                            );
                            array_push($user_result, [
                                "id" => $id,
                                "name" => $name,
                                "calls" => $calls,
                                "long_calls" => $long_calls,
                                "balances" => $balances,
                                "good_balances" => $good_balances,
                                "sum_issued_bg" => $sum_issued_bg,
                                "sum_bg" => $sum_bg,
                                "sum_plan" =>  $sum_plan
                            ]);
                        }

                        //1
                        for ($i = 0; $i < 4; $i++) {
                            $data = [];
                            foreach ($departments_result as $one_result) {
                                array_push($data, $one_result[$i]);
                            }
                            array_push(
                                $series,
                                [
                                    "name" => $name_column[$i],
                                    "data" =>  $data,
                                ]
                            );
                        }
                        $group_column_dashboard = $this->group_column_dashboard(' ', $staff_name, $series);
                        $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                        $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                        $bar_dashboard = $this->bar_dashboard(' ', $done);
                        $dashboard = [
                            "group_column_dashboard" => $group_column_dashboard,
                            "pie_dashboard" => $pie_dashboard,
                            "column_dashboard" => $column_dashboard,
                            "bar_dashboard" => $bar_dashboard,
                            "table" => $user_result,
                            "departments" => null,
                            "staff" =>  $staff_department
                        ];
                        return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                    }
                } else {
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
            

                    //переменные для 1
                    $departments_result = [];
                    $staff_name = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    $user_result = [];

                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                        $done = 0;

                    $calls = 0;
                    $long_calls = 0;
                    $balances = 0;
                    $good_balances = 0;
                    $sum_issued_bg = 0;
                    $sum_plan = 0;
                    $sum_bg = 0;
                    
                        $name = null;
                    //     //1
                        array_push($departments_result, [$calls,  $long_calls, $balances, $good_balances]);
                        array_push($staff_name, null);
                    
                            $y = 0;
                    
                            $y = 0;
                   
                        array_push(
                            $data_column,
                            [
                                "name" => $name,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                        $id = 0;
                        $i = 0;
                        
                        $data = [];
                    
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    // }
                    $group_column_dashboard = $this->group_column_dashboard(' ', $staff_name, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => null,
                        "staff" =>  null
                    ];
                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 76399:  //Юзер
                $dates = $this->date_calculation($request);
                $start = $dates[0];
                $finish = $dates[1];
                $department_id = auth()->user()->department;
                if (!empty($department_id)) {
                    $user_id =  $request["user_id"];
                    $week = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
                    $staff_department = DB::table('users')->where('role', 76399)->where('department', $department_id)->select('id', 'name')->orderby('name', 'asc')->get();
                    $staff_id = [];
                    foreach ($staff_department as $staff) {
                        array_push($staff_id, $staff->id);
                    }

                    $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // 
                    

                            $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $dates[2])->where('date', '<=', $finish)->get();

                    //         break;
                    //     default:
                    //         $result_staff_months = DB::table('qualities_months')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    // }
                    $count = $staff_department->count();

                    //переменные для 1
                    $one_staff_result = [];
                    $staff_date = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    $user_result = [];


                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                    foreach ($result_staff as $one_result) {
                        $sum_issued_bg_all =  $sum_issued_bg_all + $one_result->sum_issued_bg;
                    }
                    foreach ($result_staff_months as $one_result) {
                        $sum_plan_all =  $sum_plan_all + $one_result->sum_plan;
                    }
                    //4
                    if ($sum_plan_all == 0) {
                        $done = 0;
                    } else {
                        $done =  floor(($sum_issued_bg_all * 100) / $sum_plan_all);
                    }
                    for ($i = 0; $i < $count; $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_plan = 0;
                        $id =  $staff_id[$i];
                        foreach ($result_staff as $one_result) {
                            if ($one_result->user_id == $id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                                if ($id == $user_id) {
                                    $day = $one_result->date;
                                    $day_week = date('w', $day);
                                    $day = $week[$day_week] . date(' d.m.Y', $day);
                                    array_push($staff_date, $day);
                                }
                            }
                        }
                        foreach ($result_staff_months as $one_result) {
                            if ($one_result->user_id == $id) {
                                $sum_plan = $one_result->sum_plan + $sum_plan;
                            }
                        }
                        if ($sum_plan == 0) {
                            $sum_bg = 0;
                        } else {
                            $sum_bg = floor(($sum_issued_bg * 100) / $sum_plan); 
                        }
                        $name = $staff_department[$i]->name;
                        //1
                        array_push($one_staff_result, [$calls,  $long_calls, $balances, $good_balances]);

                        //2
                        if ($sum_issued_bg_all == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_issued_bg_all);
                        }
                        array_push(
                            $data_pie,
                            [
                                "name" => $name,
                                'y' => $y,
                                'color' => '#' . dechex(rand(0, 10000000)),
                                'x' => $sum_issued_bg
                            ]
                        );
                        //3
                        if ($sum_plan == 0) {
                            $y = 0;
                        } else {
                            $y = floor(($sum_issued_bg * 100) / $sum_plan);
                        }
                        array_push(
                            $data_column,
                            [
                                "name" => $name,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                        array_push($user_result, [
                            "id" => $id,
                            "name" => $name,
                            "calls" => $calls,
                            "long_calls" => $long_calls,
                            "balances" => $balances,
                            "good_balances" => $good_balances,
                            "sum_issued_bg" => $sum_issued_bg,
                            "sum_bg" => $sum_bg,
                            "sum_plan" =>  $sum_plan
                        ]);
                    }
                    //1
                    for ($i = 0; $i < 4; $i++) {
                        $data = [];
                        foreach ($one_staff_result as $one_result) {
                            array_push($data, $one_result[$i]);
                        }
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    }

                    $group_column_dashboard = $this->group_column_dashboard(' ', $staff_date, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => null,
                        "staff" =>  null

                    ];

                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                } else {
                    $name_column = ['Всего звонков',  'Звонки больше 1 мин', 'Балансы', 'Результативные балансы'];
            

                    //переменные для 1
                    $departments_result = [];
                    $staff_name = [];
                    $series = [];
                    //переменные для 2
                    $data_pie = [];
                    //переменные для 3
                    $data_column = [];
                    $user_result = [];

                    //переменные для всех
                    $sum_issued_bg_all = 0;
                    $sum_plan_all = 0;
                        $done = 0;

                    $calls = 0;
                    $long_calls = 0;
                    $balances = 0;
                    $good_balances = 0;
                    $sum_issued_bg = 0;
                    $sum_plan = 0;
                    $sum_bg = 0;
                    
                        $name = null;
                    //     //1
                        array_push($departments_result, [$calls,  $long_calls, $balances, $good_balances]);
                        array_push($staff_name, null);
                    
                            $y = 0;
                    
                            $y = 0;
                   
                        array_push(
                            $data_column,
                            [
                                "name" => $name,
                                'y' => $y,
                                'plan' => $sum_plan,
                                'sum' => $sum_issued_bg,
                            ]
                        );
                        $id = 0;
                        $i = 0;
                        
                        $data = [];
                    
                        array_push(
                            $series,
                            [
                                "name" => $name_column[$i],
                                "data" =>  $data,
                            ]
                        );
                    // }
                    $group_column_dashboard = $this->group_column_dashboard(' ', $staff_name, $series);
                    $pie_dashboard = $this->pie_dashboard('Продажи', $sum_issued_bg_all, $data_pie);
                    $column_dashboard = $this->column_dashboard('Выполнение плана', 'Продажи', $data_column);
                    $bar_dashboard = $this->bar_dashboard(' ', $done);
                    $dashboard = [
                        "group_column_dashboard" => $group_column_dashboard,
                        "pie_dashboard" => $pie_dashboard,
                        "column_dashboard" => $column_dashboard,
                        "bar_dashboard" => $bar_dashboard,
                        "table" => $user_result,
                        "departments" => null,
                        "staff" =>  null
                    ];
                    return response()->json($dashboard, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                break;
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }



    public function ResultsOfDay(Request $request)
    {

        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 93160:                                                     //Админ (Вадим)
            case 67274: //Рук отдела

                $constructor_table = $this->constructor_table;
                $department_id = auth()->user()->department;
                $staff_id = [];
                $calls = 0;
                $long_calls = 0;
                $balances = 0;
                $good_balances = 0;
                $sum_issued_bg = 0;
                $sum_bg = 0;

                $date_result = strtotime($request[0]["date"]);

                $today = Carbon::now()->timestamp;

                if ($date_result > $today) {
                    $obgect = ['message' => "Вы не можете выбрать данную дату.", "status" => 404];
                    return response()->json($obgect, 404, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                }
                foreach ($request->all() as $person) {
                    $chek_result = DB::table('qualities')->where('date', strtotime($person["date"]))->where('user_id',  $person['user_id'])->get();
                    if ($chek_result->count() == 0) {
                        $quality = new Quality();
                    } else {
                        $id = $chek_result[0]->id;
                        $quality = Quality::find($id);
                    }
                   // $quality = new Quality();
                    foreach ($constructor_table as $key) {
                        $key = $key['title']; //запись ключа из массива в переменную key
                        if (!empty($person[$key])) {
                            $quality->$key  = $person[$key];
                        }
                    }
                    if  (array_key_exists('calls',$person)) {
                        $calls = $calls + $person["calls"]; 
                    } 
                    if  (array_key_exists('long_calls',$person)) {
                        $long_calls = $long_calls + $person["long_calls"];
                    } 
                    if  (array_key_exists('balances',$person)) {
                        $balances = $balances + $person["balances"];
                    } 
                    if  (array_key_exists('good_balances',$person)) {
                        $good_balances = $good_balances + $person["good_balances"];
                    } 
                    if  (array_key_exists('sum_issued_bg',$person)) {
                        $sum_issued_bg = $sum_issued_bg + $person["sum_issued_bg"];
                    } 
                    if  (array_key_exists('sum_bg',$person)) {
                        $sum_bg = $sum_bg + $person["sum_bg"];
                    } 
                    $quality->date = strtotime($person["date"]);
                    array_push($staff_id, $person['user_id']);
                    $quality->save();
                }
                $date = strtotime($person["date"]);
                $result_department = DB::table('quality_departments')->where('date', $date)->where('department_id',  $department_id)->get();
                if ($result_department->count() == 0) {
                    $result = new QualityDepartment;
                } else {
                    $id = $result_department[0]->id;
                    $result = QualityDepartment::find($id);
                }
                $result->calls = $calls;
                $result->long_calls = $long_calls;
                $result->balances = $balances;
                $result->good_balances = $good_balances;
                $result->sum_issued_bg = $sum_issued_bg;
                $result->sum_bg = $sum_bg;
                $result->date = $date;
                $result->department_id = $department_id;
                $result->save();
                $today = mb_strcut($person["date"], 8, 2);
                $month_end = date('t', $date);
                if ($month_end - $today == 0) {
                    $start = strtotime(mb_strcut($person["date"], 0, 8) . '01');
                    $finish = strtotime(mb_strcut($person["date"], 0, 8) . $month_end);
                    $result_staff = DB::table('qualities')->whereIn('user_id', $staff_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                    for ($i = 0; $i < count($staff_id); $i++) {
                        $calls = 0;
                        $long_calls = 0;
                        $balances = 0;
                        $good_balances = 0;
                        $sum_issued_bg = 0;
                        $sum_bg = 0;
                        $user_id =  $staff_id[$i];
                        foreach ($result_staff as $one_result) {
                            if ($one_result->user_id == $user_id) {
                                $calls = $one_result->calls + $calls;
                                $long_calls = $one_result->long_calls + $long_calls;
                                $balances = $one_result->balances + $balances;
                                $good_balances = $one_result->good_balances + $good_balances;
                                $sum_bg = $one_result->sum_bg + $sum_bg;
                                $sum_issued_bg = $one_result->sum_issued_bg + $sum_issued_bg;
                            }
                        }
                        $result_month_one_old = DB::table('qualities_months')->where('user_id',  $user_id)->where('date', '>=', $start)->where('date', '<=', $finish)->get();
                        $id = $result_month_one_old->id;
                        $result_month_one = QualitiesMonth::find($id);
                        $result_month_one->calls = $calls;
                        $result_month_one->long_calls = $long_calls;
                        $result_month_one->balances = $balances;
                        $result_month_one->good_balances = $good_balances;
                        $result_month_one->sum_issued_bg = $sum_issued_bg;
                        $result_month_one->sum_bg = $sum_bg;
                        $result_month_one->date = $date;
                        $result_month_one->user_id = $user_id;
                        $result_month_one->save();
                    }
                }
                return response()->json("Результаты дня записаны.", 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function PlanOfMonth(Request $request)
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 93160:                                                     //Админ (Вадим)
                $date = Carbon::now()->timezone('Europe/Moscow');
                $start = strtotime(mb_strcut($date, 0, 7) . '-01');
                $month_end = date('t', $start);
                $finish = strtotime(mb_strcut($date, 0, 7) . '-' . $month_end);
                $chek = DB::table('qualities_months')->where('date', '>=', $start)->where('date', '<=', $finish)->delete();

                foreach ($request->all() as $person) {
                    $quality = new QualitiesMonth();
                    $quality->user_id = $person["user_id"];
                    $quality->sum_plan = $person["sum_plan"];
                    $quality->date = strtotime($date);
                    $quality->save();
                }
                return response()->json("План на месяц записан.", 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    public function FormForResultsOfDay()
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 67274: //Рук отдела
            case 93160: 
                $department_id = auth()->user()->department;
                if (!empty($department_id)) {
                    $users = DB::table('users')->where('role', 76399)->where('department',  $department_id)->select('id', 'name')->orderby('name', 'asc')->get();
                } else {
                    $users =[];
                }
                return response()->json($users, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 93260:                                                     //Супер Админ (главный босс Настя)
                                                                //Админ (Вадим)
                return response()->json('Функционал в разработке', 403);
                break;
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }
    public function FormForPlanOfMonth()
    {
        date_default_timezone_set('Europe/Moscow');
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93260:                                                     //Супер Админ (главный босс Настя)
            case 93160:                                                     //Админ (Вадим)
                // $date = Carbon::now()->timestamp; ->timezone('Europe/Moscow');
                $users = DB::table('users')->where('role', 76399)->select('id', 'name', 'department')->orderby('name', 'asc')->get();
                $departments = DB::table('departments')->select('id', 'name')->get();
                $last_month = date('Y-m', strtotime('now -1 month'));
                $start = strtotime($last_month . '-01');
                $month_end = date('t', $start);
                $finish = strtotime($last_month . '-' . $month_end);
                $result_staff_months = DB::table('qualities_months')->where('date', '>=', $start)->where('date', '<=', $finish)->select('user_id', 'sum_plan')->get();
                $count = $departments->count();
                $staff = [];
                for ($i = 0; $i < $count; $i++) {
                    $department_staff = [];
                    $department_id = $departments[$i]->id;
                    $department_name = $departments[$i]->name;
                    foreach ($users as $user) {
                        if ($user->department == $department_id) {
                            $user_id = $user->id;
                            $sum_plan = 0;
                            foreach ($result_staff_months as $one_result) {
                                if ($one_result->user_id == $user_id) {
                                    $sum_plan = $one_result->sum_plan;
                                    break;
                                }
                            }
                            $user->sum_plan = $sum_plan;
                            array_push($department_staff,  $user);
                        }
                    }
                    array_push($staff, ["name" => $department_name, "staff" => $department_staff]);
                    //array_push($staff, $department_staff);
                }

                return response()->json($staff, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274: //Рук отдела
            case 76399:  //Юзер
            case 67270: //Без прав
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }
   
}
