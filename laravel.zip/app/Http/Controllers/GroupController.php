<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Session;
use App\Http\Resources\SessionResource;
use App\Events\SessionEvent;
use App\Http\Resources\GrouResource;
use App\Http\Resources\User_groupResource;
use App\Models\Groups;
use App\Models\User;
use App\Models\User_group;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class GroupController extends Controller
{
    // public function create(Request $request)
    // {
    //     if (!is_numeric($request->user_id))  return response([
    //         'errors' => '"user_id": ["invalid input syntax."]'
    //     ], 422);
    //     if ($request->user_id) {
    //         $user_exist = User::where('id', '=', $request->user_id)->first();
    //         if (!$user_exist) return response(['errors' => '"user_id": ["The user_id is not exist."]'], 422);
    //          if ($request->user_id == auth()->id()) return response(['errors' => '"user_id": ["Cant send a message to yourself."]'], 422);
    //         $data = Session::where('user2_id', '=', $request->user_id)->first();
    //         if (!$data) {
    //             $session = Session::create(['user1_id' => auth()->id(), 'user2_id' => $request->user_id]);
    //             $modifiedSession = new SessionResource($session);
    //             broadcast(new SessionEvent($modifiedSession, auth()->id()));
    //             return $modifiedSession;
    //         }
    //         return new SessionResource($data);
    //     } else  return response([
    //         'errors' => '"user_id": ["The user_id field is required."]'
    //     ], 422);
    // }

    // create new group and add user 
    public function create(Request $request)
    {
        $validator = Validator::make(['group_name' => $request->group_name, 'user_id' => $request->user_id], [
            'group_name' => 'required',
            "user_id"    => "required|array",
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            //check by group name
            $group =  Groups::where('group_name', trim($request->group_name))->first();
            if ($group) return response(['success' => 'false', 'message' => 'group name already exists.', 'code' => '404']);
            //create group
            $group = Groups::Create(['group_name' => $request->group_name, 'user_id' => auth()->id()]);
            if ($group->id) {
                //add user  to group
                foreach ($request->user_id  as $user_id) {
                    User_group::Create(['group_id' => $group->id, 'user_id' => $user_id]);
                }
            }
            return response(['success' => 'true', 'message' => 'group create successfully.', 'code' => '200']);
        }
    }

    // Update group and Update users
    public function store(Request $request)
    {
        $validator = Validator::make(['group_name' => $request->group_name, 'user_id' => $request->user_id], [
            'group_name' => 'required',
            "user_id"    => "required|array",
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            //get group
            $group = Groups::find($request->group_id);
            if ($group) {
                $group->group_name = $request->group_name;
                $group->save();
                //Update group
                $userIdsInDB = User_group::where('group_id', $group->id)->get('user_id');
                foreach ($userIdsInDB  as $id)
                    if (!in_array((int)$id->user_id,  $request->user_id))
                        User_group::where('user_id', $id->user_id)->where('group_id', $group->id)->delete();
                foreach ($request->user_id  as $PostIds)
                    User_group::updateOrCreate(['group_id' => $group->id, 'user_id' => $PostIds]);
                return response(['success' => 'true', 'message' => 'group updated successfully.', 'code' => '200']);
            }
        }
    }
    //get all groups
    public function index()
    {
        return GrouResource::collection(Groups::withCount('User_groups')->get());
    }
    //get users info from groups by group_id
    public function getUsersInGrouById($group_id)
    {
        return User_groupResource::collection(User_group::where('group_id', $group_id)->get());
    }
    //delete group
    public function delete(Request $request)
    {
        $Groups = Groups::withCount('User_groups')->where('id', '=', $request->group_id)->delete();
        if ($Groups)  return  response(['success' => 'true', 'message' => 'group deleted successfully.', 'code' => '200']);
    }
    //All Group info For User login         | my groups |   
    public function AllGroupForUserlogin()
    {
        $group_ids = User_group::where('user_id', auth()->id())->get('group_id');
        return GrouResource::collection(Groups::withCount('User_groups')->whereIn('id', $group_ids)->get());
    }
}
