<?php

namespace App\Http\Controllers;

use App\Models\File;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use App\Http\Requests\StoreFileRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Validator;

class FilesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $files = File::all();

        return  $files;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('files.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  StoreFileRequest  $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'file' => ['required', 'mimes:jpg,jpeg,bmp,png,doc,docx,csv,rtf,xlsx,xls,txt,pdf,zip', 'max:2048']
            'file' => 'required|max:1',
            'file.*' => 'mimes:jpg,jpeg,bmp,png,doc,docx,csv,rtf,xlsx,xls,txt,pdf,zip,wav', 'max:2048'
        ]); // create the validations
        if (!$validator->fails()) //check all validations are fine, if not then redirect and show error messages
        {
            // Filename to store
            $fileNameToStore = auth()->id() . '_' . time() . '.' . $request->file->extension();
            // Upload File
            $path = $request->file('file')->storeAs('public/users_files', $fileNameToStore);
            $type = $request->file->getClientMimeType();
            $size = $request->file->getSize();
            //Add to DB
            File::create([
                'user_id' => auth()->id(),
                'name' => $fileNameToStore,
                'type' => $type,
                'size' => $size,
                'path' => $path
            ]);
            return response(['success' => 'true', 'message' => 'File added successfully.', 'code' => '200']);
        } else {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        }
    }
}
