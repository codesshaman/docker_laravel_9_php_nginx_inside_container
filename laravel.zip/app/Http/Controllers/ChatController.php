<?php

namespace App\Http\Controllers;

use App\Events\GroupChatEvent;
use App\Events\MsgReadEvent;
use App\Events\PrivateChatEvent;
use App\Http\Resources\ChatResource;
use App\Http\Resources\GrouResource;
use App\Http\Resources\MessageResource;
use App\Models\Chat;
use App\Models\Chat_File;
use App\Models\File;
use App\Models\Groups;
use App\Models\Message;
use App\Models\User;
use App\Models\User_aGroup;
use App\Models\User_Group;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Resources\User_groupResource;
use App\Models\Message_Group;
use App\Models\MessageGroup;
use App\Models\MessagesGroups;

class ChatController extends Controller
{
    //send meesage to user

    public function message(Request $request)
    {
        if (User::where('id', $request->receiver_id)->first()) {

            $validator = Validator::make($request->all(), [
                'receiver_id' => 'required|numeric',
                'content' => 'nullable',
                'files' => 'max:10',
                'files.*' => 'mimes:jpg,jpeg,bmp,png,doc,docx,csv,rtf,xlsx,xls,txt,pdf,zip,wav', 'max:2048'
            ]);
            if ($validator->fails()) {
                $content = $validator->errors()->first();
                $errors = $validator->errors();
                $code = '422';
                $response = array(
                    'success' => false,
                    'content' => $content,
                    "errors" => $errors
                );
                return new JsonResponse($response, $code);
            } else {
                if (!$request->content && !$request->file('files'))
                    return response(['success' => 'false', 'message' => 'content or files required.', 'code' => '422']);
                $File_ids = null;
                $message_type = "text";

                // save file in files tbl
                if ($request->file('files')) {
                    $message_type = "file";
                    foreach ($request->file('files') as $file) {
                        $File_ids[] = $this->SaveFiles($file);
                    }
                }
                //add new record to `messages` tbl
                $newMessage =  Message::Create(['content' => $request->content, 'receiver_id' => $request->receiver_id, 'user_id' => auth()->id(), 'file_id' => $File_ids, 'message_type' => $message_type]);
                $newMessage = Message::with('users')->select('id', 'content', 'user_id', 'receiver_id', 'content', 'is_deleted', 'message_type', 'created_at')->where('id', $newMessage->id)->get();
                // send to sockit
                broadcast(new PrivateChatEvent($request->receiver_id, MessageResource::customCollection($newMessage, "PrivetMsgSocket")));
                // broadcast(new PrivateChatEvent($request->content, $chat));
                return response(['success' => 'true', 'messages' => 'message send successfully.', 'code' => '200']);
            }
        } else  return response(['success' => 'true', 'message' => 'user_id receiver not exists.', 'code' => '200']);
    }
    //send Messaget to Group By group id
    public function messageGroup(Request $request, $group_id)
    {
        // check if group exist 
        if (!Groups::where('id', $group_id)->first())
            return response(['success' => 'true', 'message' => 'group id not exists.', 'code' => '200']);
        // check if user in this group
        if (!User_groupResource::collection(User_group::where('group_id', $group_id)->where('user_id', auth()->id())->get())->first())
            return response(['success' => 'true', 'message' => 'You are not in this group.', 'code' => '200']);
        $validator = Validator::make($request->all(), [
            'content' => 'nullable',
            'files' => 'max:10',
            'files.*' => 'mimes:jpg,jpeg,bmp,png,doc,docx,csv,rtf,xlsx,xls,txt,pdf,zip,wav', 'max:2048'
        ]);
        if ($validator->fails()) {
            $content = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'content' => $content,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            $File_ids = null;
            $message_type = "text";
            // save file in files tbl
            if ($request->file('files')) {
                $message_type = "file";
                foreach ($request->file('files') as $file) {
                    $File_ids[] = $this->SaveFiles($file);
                }
            }
            //add new record to messages Group tbl
            $newMessage = MessagesGroups::Create(['content' => $request->content, 'receiver_id' => $group_id, 'user_id' => auth()->id(), 'file_id' => $File_ids, 'message_type' => $message_type]);
            $Message = MessagesGroups::with('groups:id,group_name')->select('id', 'content', 'user_id', 'receiver_id', 'content', 'is_deleted', 'message_type',  'created_at')->where('id', $newMessage->id)->get();
            // send to sockit
            $this->SendNotifyToGroup($group_id, $Message);
            return response(['success' => 'true', 'messages' => 'message send to group successfully.', 'code' => '200']);
        }
    }

    public function SendNotifyToGroup($group_id, $Message)
    {
        $users =   User_group::select('user_id')->where('group_id', $group_id)->get();
        if ($users) foreach ($users as   $value) {
            if ($value->user_id != auth()->id())
                broadcast(new GroupChatEvent($value->user_id, MessageResource::customCollection($Message, "messageGroup")));
        }
    }


    public function SaveFiles($file)
    {
        $fileNameToStore = auth()->id() . '_' . time() . '.' . $file->extension();
        // Upload Files
        $path = $file->storeAs('public/chats_files', $fileNameToStore);
        $type = $file->getClientMimeType();
        $size = $file->getSize();
        return Chat_File::create(['user_id' => auth()->id(), 'name' => $fileNameToStore, 'type' => $type, 'size' => $size, 'path' => $path])->id;
    }
    //read Messages for User By message_id   
    public function read(Request $request)
    {
        $validator = Validator::make($request->all(), [
            // 'message_id' => 'required|numeric',
            'receiver_id' => 'required|numeric',
            'is_group' => 'required|boolean',

        ]);
        if ($validator->fails()) {
            $content = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'content' => $content,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {

            // for privet messages 
            if (!$request->is_group) {
                Message::whereNull("read_at")->where("user_id", $request->receiver_id)->where("receiver_id", auth()->id())->update(['read_at' => Carbon::now()]);
                // broadcast(new MsgReadEvent(new ChatResource($chat), $chat->session_id));
                return response(['success' => 'true', 'message' => 'message reading successfully.', 'code' => '200']);
            }
            // for groups messages 
            else
                //get messages not reading 
                $messages = MessagesGroups::select('reading_id', 'read_at', 'id')->where("receiver_id", $request->receiver_id)->get();
            if ($messages) {
                // $read_at = Carbon::now();
                foreach ($messages as $msg) {
                    $reading_ids  = null;
                    if (is_null($msg->read_at))
                        MessagesGroups::whereNull("read_at")->where("receiver_id", $request->receiver_id)->where("id", $msg->id)->update(['reading_id' =>  [auth()->id()], 'read_at' => Carbon::now()]);
                    else if ($msg->reading_id) {
                        $reading_ids = json_decode($msg->reading_id);
                        if (is_array($reading_ids)) {
                            if (!in_array(auth()->id(), $reading_ids)) {
                                array_splice($reading_ids, 0, 0, auth()->id());
                            }
                        }
                        MessagesGroups::whereNotNull("read_at")->where("receiver_id", $request->receiver_id)->where("id", $msg->id)
                            ->update(['reading_id' => $reading_ids, 'read_at' => $msg->read_at]);
                    }
                }
                return response(['success' => 'true', 'message' => 'message reading successfully.', 'code' => '200']);
            } else return 0;
        }
    }
    //get Messages for User By receiver_id   
    public function index($receiver_id)
    {
        $sender = auth()->id();
        $messages =  Message::select('user_id', 'receiver_id', 'id',  'content', 'message_type', 'created_at', 'read_at', 'is_deleted')->with('users:id,name')->with('user_sender:id,name')
            ->Where(function ($query) use ($sender, $receiver_id) {
                $query->where("user_id", $sender)->where("receiver_id", $receiver_id);
            })->orWhere(function ($query) use ($sender, $receiver_id) {
                $query->Where("user_id", $receiver_id)->Where("receiver_id", $sender);
            })->orderBy('created_at', 'desc')->paginate(25);
        if ($messages->items()) {
            $sortedResult = $messages->getCollection()->sortBy('created_at')->values();
            $newsorting = $messages->setCollection($sortedResult);
            return MessageResource::collection($newsorting);
        }

        return response(['success' => 'true', 'message' => 'No messages.', 'code' => '200']);
    }
    // Get all messages for user(me) in group by group_id
    public function indexGroup($group_id)
    {
        // check  if user in this group 
        $group_ids = User_group::where('user_id', auth()->id())->where('group_id', $group_id)->get('group_id');
        if ($group_ids->isEmpty()) return response(['success' => 'true', 'message' => 'You are not in this group.', 'code' => '200']);
        else
            $messages =  MessagesGroups::select('user_id', 'receiver_id', 'id', 'content', 'message_type', 'created_at', 'read_at',  'is_deleted')
                ->with('user_sender:id,name')->with('users:id,name')->Where("receiver_id", $group_id)
                ->orderBy('created_at', 'asc')->paginate(25);
        if ($messages->items()) return MessageResource::customCollection($messages, "messageGroup");
        return response(['success' => 'true', 'message' => 'No messages.', 'code' => '200']);
    }
    //delete All messages from user by user id 
    public function delAllmessagesFromUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'receiver_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            $messages = Message::where('user_id', auth()->id())->where('receiver_id', $request->receiver_id)->update(['is_deleted' => true]);
            if ($messages)  return response(['success' => 'true', 'message' => 'message deleted successfully.', 'code' => '200']);
        }
    }
    //delete One message  from user by message id
    public function delOneMessageFromUser(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'message_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            $messages = Message::where('user_id', auth()->id())->where('id', $request->message_id)->update(['is_deleted' => true]);
            if ($messages)  return response(['success' => 'true', 'message' => 'message deleted successfully.', 'code' => '200']);
            else return response(['success' => 'true', 'message' => 'There are no messages to delete.', 'code' => '200']);
        }
    }
    //delete All messages from Group by group id 
    public function delAllmessagesFromGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'group_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            $messages = MessagesGroups::where('user_id', auth()->id())->where('receiver_id', $request->group_id)->update(['is_deleted' => true]);
            if ($messages)  return response(['success' => 'true', 'message' => 'message deleted successfully.', 'code' => '200']);
        }
    }
    //delete One message  from Group by message id
    public function delOneMessageFromGroup(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'message_id' => 'required|numeric',
        ]);
        if ($validator->fails()) {
            $message = $validator->errors()->first();
            $errors = $validator->errors();
            $code = '422';
            $response = array(
                'success' => false,
                'message' => $message,
                "errors" => $errors
            );
            return new JsonResponse($response, $code);
        } else {
            $messages = MessagesGroups::where('user_id', auth()->id())->where('id', $request->message_id)->update(['is_deleted' => true]);
            if ($messages)  return response(['success' => 'true', 'message' => 'message deleted successfully.', 'code' => '200']);
            else return response(['success' => 'true', 'message' => 'There are no messages to delete.', 'code' => '200']);
        }
    }
    public function allMessages()
    {
        $a = Message::selectRaw("receiver_id,user_id")->Where("user_id", auth()->id())->groupBy("receiver_id", "user_id");
        $message = Message::selectRaw(" user_id,receiver_id")->Where("receiver_id", auth()->id())->groupBy("receiver_id", "user_id")
            ->union($a)->with('users:id,name')->with('user_sender:id,name')->orderBy("user_id", "asc")->get();
        return MessageResource::customCollection($message, "allMessages");
    }
}
