<?php

namespace App\Http\Controllers;


use App\Models\Banks;
use App\Http\Controllers\Controller;
use App\Models\BanksComment;
use App\Models\News;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;


class BanksController extends Controller
{
    protected $keys;
    public function __construct()
    {
        //Массив для проверки столбцов и формирования
        //Json для отправки на фронт
        $this->keys = [
            ['Название банка', 'title', 'type'],
            ['Логотип', 'logo', 'type'],
            ['Возврат аванса', 'avance_return', 'filter'],
            ['В валюте', 'exchange', 'filter'],
            ['Лимит на клиента', 'limit_client', 'num'],
            ['Лимит БГ', 'limit_bg', 'num'],
            ['Сроки исполнения', 'limit_month', 'num'],
            ['Сроки создания', 'exec_deadline', 'num'],
            ['Сроки ГО ', 'go_deadline', 'num'],
            ['Размер БГ без опыта ', 'bg_size', 'num'],
            ['Берет ли дольку ', 'fraction_collecting', 'filter'],
            ['Берёт ли ГУП-МУП', 'gup_mup', 'filter'],
            ['Берет ли с плохой НБКИ ', 'nbki', 'filter'],
            ['Берет ли переобеспечение ', 'support', 'filter'],
            ['Берет ли оплату с третьих лиц ', 'payment', 'filter'],
            ['Берет ли без номера на закупках ', 'number', 'filter'],
            ['Берет ли компании, у которых ФЛ не резидент ', 'resident', 'filter'],
            ['Берет ли Кавказ ', 'caucasian', 'filter'],
            ['Берет ли Крым ', 'crimea', 'filter'],
            ['Завышение ', 'overstatement', 'type'],
            ['Закрытые', 'closed', 'filter'],
            ['БГ больше ли НМЦК', 'nmck', 'filter'],
            ['Убытки', 'losses', 'filter'],
            ['615', 'p615', 'filter'],
            ['КИК ', 'kik', 'filter'],
            ['КБГ ', 'kbg', 'filter'],
            ['Делает ли скидку', 'discount', 'filter'],
            ['Доставка ', 'delivery', 'filter'],
            ['Берет ли под поручительство ', 'guarantor', 'filter'],
            ['275 ФЗ ', 'fz_275', 'filter'],
            ['Дата изменения ', 'changing_date', 'type'],
            ['505 ', 'p505', 'filter'],
        ];
    }
    //функция собирающая JSON для 1 банка
    private function OneBankJson($bank, $bank_comment, $keys)
    {
        foreach ($keys as $row) {
            $key = $row[1];
            if (is_bool($bank->$key)) {
                $info = "filter";
            } elseif (is_int($bank->$key)) {
                $info = "num";
            } elseif (is_string($bank->$key)) {
                $info = "type";
            } else {
                if ($key == 'logo' || $key == 'overstatement') {
                    $info = "type";
                } else {
                    $info = "num";
                }
            }
            if (!empty($bank_comment->$key)) {
                $bank->$key = [
                    "title" => $row[0],
                    $info => $bank->$key,
                    "comment" => $bank_comment->$key
                ];
            } else {
                $bank->$key = [
                    "title" => $row[0],
                    $info => $bank->$key
                ];
            }
        }
        return $bank;
    }

    //функция собирающая JSON для всех банков
    private function BanksJson($banks,  $banks_comments)
    {
        $keys = $this->keys;
        //цикл перебора всех строк таблицы banks
        foreach ($banks as $bank) {
            $id = $bank->id;
            foreach ($banks_comments as $one_bank) {
                if ($one_bank->id == $id) {
                    $bank_comment = $one_bank;
                    break;
                }
            }
            $bank = $this->OneBankJson($bank,  $bank_comment, $keys);
        }
        return response()->json($banks, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
    }

    //конструктор банков для фронта
    public function bankBuild()
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $keys = $this->keys;
                $constructor = [];
                $constructor['id'] = 'createBank';
                foreach ($keys as $key) {
                    if ($key[1] == 'logo' || $key[1] == 'title' || $key[1] == 'changing_date') {
                        $constructor[$key[1]] = ['title' => $key[0], $key[2] => null];
                    } else {
                        $constructor[$key[1]] = ['title' => $key[0], $key[2] => null, 'comment' => null];
                    }
                }
                return response()->json($constructor, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    //API запрос всех банков
    public function AllBanks()
    {
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
                $banks = DB::table('banks')->get();
                $banks_comments = DB::table('banks_comments')->get();
                break;
            case 67274:
            case 76399:
                $banks = DB::table('banks')->where('visible', 'true')->get();
                $banks_comments = DB::table('banks_comments')->get();
                break;
            case 67270:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
        return $this->BanksJson($banks,  $banks_comments, 200);
    }

    //API запрос одного банка
    public function OneBank($id)
    {
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
                $bank = DB::table('banks')->where('id', $id)->get();
                break;
            case 67274:
                $bank = DB::table('banks')->where('id', $id)->where('visible', 'true')->get();
                break;
            case 76399:
                $bank = DB::table('banks')->where('id', $id)->where('visible', 'true')->get();
                break;
            case 67270:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
        switch ($bank->count()) {
            case 0:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            case 1:
                $keys = $this->keys;
                $bank = $bank[0];
                $id = $bank->id;
                $bank_comment = DB::table('banks_comments')->where('id', $id)->get();
                $bank = $this->OneBankJson($bank,  $bank_comment[0], $keys);
                return response()->json($bank, 200, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
        }
    }

    //API запрос удаления банка
    public function deleteBank($id)
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $bank = Banks::find($id);
                #Создание новой новости и отправки данных в Socket
                News::newNews($bank->title,  'Удален банк ' . $bank->title . '.', 'Удален банк ' . $bank->title . '.');
                #Удаление банка
                BanksComment::find($id)->delete();
                $bank->delete();
                return response()->json('Банк успешно удален!', 202, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67270:
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
                break;
        }
    }

    //API запрос изменения банка
    public function updateBank($id, Request $request)
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $keys = $this->keys;

                $bank = Banks::find($id);
                $bank_comment = BanksComment::find($id);

                $update_title = [];
                $count_update_key = 0;

                foreach ($keys as $row) {
                    $key = $row[1];
                    if ($key == 'changing_date') continue; //пропуск столбцов
                    if ($request->has($key)) {
                        $new_value  = $request->input(key: $key);
                        $bank->$key  = $new_value;
                        if (is_bool($new_value)) {
                            switch ($new_value) {
                                case true:
                                    $new_value = 'да';
                                    break;
                                case false:
                                    $new_value = 'нет';
                                    break;
                            }
                        }
                        if ($key == 'logo') {
                            $update_title[$count_update_key] = ' изменен логотип';
                        } else {
                            $update_title[$count_update_key] = 'параметр "' . mb_strtolower($row[0]) . '" изменен на ' . $new_value;
                        }
                        $count_update_key++;
                    }
                    if ($request->has($key . '_c')) {
                        $new_comment = $request->input(key: $key . '_c');
                        if (isset($new_comment)) {
                            if ($bank_comment->$key === null) {
                                $update_title[$count_update_key] = 'в параметр "' . mb_strtolower($row[0]) . '" добавлен комментарий "' .  $new_comment . '"';
                            } else {
                                $update_title[$count_update_key] = 'в параметр "' . mb_strtolower($row[0]) . '" комментарий изменен на "' .  $new_comment . '"';
                            }
                        } else {
                            $update_title[$count_update_key] = 'в параметр "' . mb_strtolower($row[0]) . '" удален коментарий';
                        }
                        $bank_comment->$key  = $new_comment;
                        $count_update_key++;
                    }
                }
                switch ($count_update_key) {
                    case 0:
                        return response()->json('no update', 205);
                        break;
                    default:
                        $new_info = 'В банк ' .  $bank->title . ' внесены изменения: ';
                        for ($i = 0; $i < $count_update_key; $i++) {
                            $new_info = $new_info . $update_title[$i];
                            if ($i != $count_update_key - 1) {
                                $new_info = $new_info . ', ';
                            } else {
                                $new_info = $new_info . '. ';
                            }
                        }

                        $date = Carbon::now()->timezone('Europe/Moscow');
                        $bank->changing_date = $date;
                        $bank->save();
                        $bank_comment->save();
                        #Создание новой новости и отправки данных в Socket
                        News::newNews($bank->title,  $new_info, 'В банк ' . $bank->title . ' внесены изменения.');
                        break;
                }
                return response()->json("Банк успешно изменен!", 202, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    //API запрос изменения видимости банка
    public function updateVisible($id, Request $request)
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $bank = Banks::find($id);
                $bank->visible = $request[0];
                $bank->save();
                switch ($request[0]) {
                    case true:
                        $new_visible = "Банк " . $bank->title . " снова работает.";
                        break;
                    case false:
                        $new_visible = "Банк " . $bank->title . " приостановил работу.";
                        break;
                }
                #Создание новой новости и отправки данных в Socket
                News::newNews($bank->title,  $new_visible, $new_visible);
                return response()->json("Видимость банка успешно изменена.", 202, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;

            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;

            default:
                return response()->json('Ошибка.', 405);
                break;
        }
    }

    //API запрос добавления банка
    public function createBank(Request $request)
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $keys = $this->keys;
                $bank = new Banks();
                $bank_comment = new BanksComment();
                //$news = new News();
                $bank->title  = $request->input(key: 'title');
                $bank->logo  = $request->input(key: 'logo');
                //цикл перебора всех столбцов таблицы banks
                foreach ($keys as $key) {
                    $key = $key[1]; //запись ключа из массива в переменную key
                    if ($request->has($key)) {
                        $bank->$key  = $request->input(key: $key);
                    }
                    if ($request->has($key . '_c')) {
                        $bank_comment->$key  = $request->input(key: $key . '_c');
                    }
                }
                $date = Carbon::now()->timezone('Europe/Moscow'); //запись текущей даты и времени

                $bank->changing_date = $date;

                $bank->save(); //создание записи в тб

                $bank_comment->id = $bank->id;
                $bank_comment->save();
                #Создание новой новости и отправки данных в Socket
                News::newNews($bank->title, 'Добавлен новый банк ' . $request->input(key: 'title') . '.', 'Добавлен новый банк ' . $request->input(key: 'title') . '.');
                return response()->json('Новый банк успешно добавлен!', 201, ['Content-type' => 'application/json;charset=utf-8'], JSON_UNESCAPED_UNICODE);
                break;
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }

    //Фильтрация банков
    public function banksFilter(Request $request)
    {
        $checker = auth()->user()->role;
        switch ($checker) {
            case 93160:
            case 93260:
                $whereArray = [];
                break;
            case 67274:
                $whereArray = [['visible', 'true']];
                break;
            case 76399:
                $whereArray = [['visible', 'true']];
                break;
            case 67270:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
        $keys = $this->keys;
        //$whereArray - массив с для формирования запроса в бд
        //по оператору WHERE

        //если title не пустой приходит в запросе то сортировка по алфавиту
        $title = null;
        //цикл по для формирования массива $whereArray
        foreach ($keys as $row) {
            //проверка на существование значения по ключу
            if ($request->input(key: $row[1]) !==  null) {
                //проверка на boolean тип значения по ключу
                if (is_bool($request->input(key: $row[1]))) {
                    //
                    $whereArray[] = [$row[1], $request->input(key: $row[1])];
                }
                //проверка на string тип значения по ключу
                else if (is_string($request->input(key: $row[1]))) {

                    if ($row[1] == 'title') {
                        $title = $request->input(key: $row[1]);
                    } else {
                        $whereArray[] = [$row[1], $request->input(key: $row[1])];
                    }
                }
                //если нет то сюда записывается пример: ["limit_client", ">=", 9000000]
                else {

                    $whereArray[] = $request->input(key: $row[1]);
                }
            }
        }
        if (!empty($title)) {
            //фильтрация банков с сортировкой по алфавиту по столбцу title
            if ($title == "a") {
                $banks = DB::table('banks')->where($whereArray)->orderby('title', 'asc')->get();
            }
            if ($title == "z") {
                $banks = DB::table('banks')->where($whereArray)->orderby('title', 'desc')->get();
            }
        } else {
            $banks = DB::table('banks')->where($whereArray)->get();
        }
        $banks_comments = DB::table('banks_comments')->get();
        return $this->BanksJson($banks,  $banks_comments, 200);
    }
}
