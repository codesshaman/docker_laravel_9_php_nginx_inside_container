<?php

namespace App\Http\Controllers;

use App\Models\Banks;
use App\Http\Controllers\Controller;
use App\Models\BanksComment;
use App\Models\News;
use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Env;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\Facades\JWTAuth;

class UsersController extends Controller
{ 
    public function Users()
    {
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
            case 67274:
                case 76399:
                $users = DB::table('users')
                ->where('visible', 'true')
                ->select("users.id", "users.name")
                ->orderby("users.name", "asc")
                ->get();
                //$role = DB::table('roles')->union($users)->get();
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    
        return response()->json($users, 200, ['Content-type'=>'application/json;charset=utf-8'],JSON_UNESCAPED_UNICODE);
    }
    public function AllUsers()
    {
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        switch ($checker) {
            case 93160:
            case 93260:
                $users = DB::table('users')
                ->join('roles', 'users.role', '=', 'roles.id')
                ->where('visible', 'true')
                ->select("users.id as key", "users.name", "users.email", "roles.role as roleName", "roles.id as roleId")
                ->orderby("users.name", "asc")
                ->get();
                //$role = DB::table('roles')->union($users)->get();
                break;
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    
        return response()->json($users, 200, ['Content-type'=>'application/json;charset=utf-8'],JSON_UNESCAPED_UNICODE);
    }

    public function changeUsersRole(Request $request)
    {
        //$checker для хранит id роли пользователя
        //auth проверяет введенный в header токен и определяет существует такой ли пользователь
        $checker = auth()->user()->role;
        //switch для реагирования сервера на ту или иную роль
        
        if(auth()->user()->id !== $request['id']){

        
        switch ($checker) {
            
            case 93260:
                
                $user = User::find($request['id']);
                $user -> role = $request['role'];
                $user -> save();
                return response()->json("Роль успешно изменена!", 202);
            case 93160:
                $changeUserRole = DB::table('users')->where('id', $request['id'])->select('role')->get();

                if($request['role'] >= auth()->user()->role){
                    return response()->json('Нельзя давать права, которые равны или больше ваших', 403);
                }else if($changeUserRole[0]->role >= auth()->user()->role){
                    return response()->json('Нельзя влиять на права, которые больше или равны вашим правам', 403);
                }else{
                    $user = User::find($request['id']);
                    $user -> role = $request['role'];
                    $user -> save();
                    return response()->json("Роль успешно изменена!", 202);
                }
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;
            default:
                return response()->json('Ошибка.', 405);
        }
    }else{
        return response()->json('Вы не можете менять роль у себя же!', 403);
    }
    
        //return response()->json($users, 200, ['Content-type'=>'application/json;charset=utf-8'],JSON_UNESCAPED_UNICODE);
    }
    public function deleteUser($id)
    {
        $checker = auth()->user()->role;
        $my_id = auth()->user()->id;
        switch ($checker) {
            case 93160:
                $user = User::find($id);
                $role = $user -> role;
                if ($role < 93160){
                    $user->visible = false;
                    $user->save();
                    return response()->json('Пользователь успешно удален!', 202);
                } else {
                    return response()->json('Недостаточно прав доступа для удаления данного пользователя.', 403);
                }
                break;
            case 93260:
                if ($id == $my_id) {
                    return response()->json('Вы не можете удалить себя!', 403);
                } else {
                    $user = User::find($id);
                    $user->visible = false;
                    $user->save();
                    return response()->json('Пользователь успешно удален!', 202);
                }
                break;
            case 67274:
            case 76399:
                return response()->json('Недостаточно прав доступа.', 403);
                break;

            default:
                return response()->json('Ошибка.', 405);
                break;

        }
    }

}
