<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MessagesGroups extends Model
{
    
    protected $fillable = [
        'content', 'receiver_id', 'user_id', 'file_id', 'message_type',  'reading_id'
    ];
    protected $casts = ['file_id' => 'array','read_at' => 'datetime',];

    public function users(){
        return $this->belongsTo(User::class,'receiver_id','id');
    }
    public function user_sender(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function groups(){
        return $this->belongsTo(Groups::class,'receiver_id','id');
    }
}
