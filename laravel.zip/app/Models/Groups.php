<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Groups
 * @package App\Models
 *
 * @property boolean block
 */
class Groups extends Model
{

    protected $fillable = ['group_name', 'user_id'];

    protected $guarded = [];
    public function User_groups()
    {
        return $this->hasMany(User_group::class, 'group_id');
    }
    public function groups()
    {
        return $this->belongsTo(Groups::class,'user_id');
    }
    // public function user(){
    //     return $this->belongsTo(User::class,'user_id','id');
        
    // }
    
    // public function chats()
    // {
    //     return $this->hasManyThrough(Chat::class, Message::class);
    // }

    // public function messages()
    // {
    //     return $this->hasMany(Message::class);
    // }

    // public function deleteChats()
    // {
    //     $this->chats()->where('user_id', auth()->id())->delete();
    // }

    // public function deleteMessages()
    // {
    //     $this->messages()->delete();
    // }


    // public function block()
    // {
    //     $this->is_block = true;
    //     $this->blocked_by = auth()->id();
    //     $this->save();
    // }

    // public function unblock()
    // {
    //     $this->is_block = false;
    //     $this->blocked_by = null;
    //     $this->save();
    // }
}
