<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message extends Model
{
    
    protected $fillable = [
        'content', 'receiver_id', 'user_id', 'file_id', 'message_type'
    ];
    protected $casts = ['file_id' => 'array','read_at' => 'datetime',];

    public function users(){
        return $this->belongsTo(User::class,'receiver_id','id');
    }
    public function user_sender(){
        return $this->belongsTo(User::class,'user_id','id');
    }
    public function groups(){
        return $this->belongsTo(Groups::class,'receiver_id','id');
    }
    // public function chats()
    // {
    //     return $this->hasMany(Chat::class);
    // }

    // public function createForSend($session_id)
    // {
    //     return $this->chats()->create([
    //         'session_id' => $session_id,
    //         'type' => 0,
    //         'user_id' => auth()->id()]);
    // }

    // public function createForReceive($session_id, $to_user)
    // {
    //     return $this->chats()->create([
    //         'session_id' => $session_id,
    //         'type' => 1,
    //         'user_id' => $to_user]);
    // }
}
