<?php

namespace App\Models;

use App\Events\NotificationBankEvent;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Redis;
use Illuminate\Console\Scheduling\Event;
use App\Events\NotificationNews;
use Carbon\Carbon;

class News extends Model
{
    use HasFactory;
    public $timestamps = false;

    // public static  function eventSocket($id, $bank_news){
    //     Redis::set('news' . $id, $bank_news);
    //     event(new NotificationNews($bank_news));
    // }

    public static  function newNews($title, $text_news, $text_ws){
        $news = new News();
        $news -> title = $title;
        $news -> text_news = $text_news; 
        $news -> text_ws = $text_ws; 
        $time = Carbon::now()->timestamp;
        $news -> date = $time;
        $news -> save();
        #WebSocket 
        $id = $news -> id;
        broadcast(new NotificationBankEvent($id, $text_ws));
    }
}
