<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Chat_File extends Model
{
    protected $table = 'chat_files';

    protected $fillable = [
        'user_id',
        'name',
        'type',
        'size',
        'path'
    ];
    use HasFactory;
}
