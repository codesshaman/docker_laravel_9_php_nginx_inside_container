<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class User_group
 * @package App\Models
 *
 * @property boolean block
 */
class User_group extends Model
{
    protected $fillable = ['group_id', 'user_id'];

    public function groups()
    {
        return $this->belongsTo(Groups::class,'user_id');
    }

 
}
