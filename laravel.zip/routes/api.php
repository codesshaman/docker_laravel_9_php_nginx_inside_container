<?php

use Illuminate\Http\Request;
use App\Models\User;
use GuzzleHttp\Middleware;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Password;
use Illuminate\Support\Facades\Route;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Auth\Events\PasswordReset;
use Illuminate\Auth\Events\Verified;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\BanksController;
use App\Http\Controllers\NewsController;
use App\Http\Controllers\StatisticsController;
use App\Http\Controllers\ChatsController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\BlockController;
use App\Http\Controllers\FilesController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\EmailController;
use App\Http\Controllers\GroupController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group([
    'prefix' => 'auth'
], function () {
    //реализация проверки аутентификации пользователя
    Route::get('check', [AuthController::class, 'check']);
    //реализация логина
    Route::post('login', [AuthController::class, 'login']);
    //реализация регистрации
    Route::post('registration', [AuthController::class, 'registration']);
    //реализация выхода 
    Route::post('logout', [AuthController::class, 'logout']);
    //реализация обновление токена
    Route::post('refresh', [AuthController::class, 'refresh']);
    //реализация аутентификации пользователя
    Route::post('me', [AuthController::class, 'me']);

    // ###################################################

    //для проверки email и отправки ссылки для сброса
    Route::post('/forgot-password', [EmailController::class, 'forgotPassword']);

    //Компонента сброса пароля с выданным для этого токеном
    Route::get('/reset-password', [EmailController::class, 'resetPassword'])->middleware('guest')->name('password.reset');;

    //обработка пароля и его изменение
    //PAGE добавил*********************
    Route::post('/reset-password/page', [EmailController::class, 'resetPassword'])->middleware(['guest'])->name('password.update');
    // ########################################################

    Route::group(['middleware' => 'auth:api'], function () {
        //Манипуляции с банками
        Route::group(['namespace' => 'Bank', 'prefix' => 'banks'], function () {
            Route::get('/', [BanksController::class, 'allBanks']);
            Route::get('/build', [BanksController::class, 'bankBuild']);
            Route::get('/{id}', [BanksController::class, 'oneBank']);
            Route::delete('/{id}', [BanksController::class, 'deleteBank']);
            Route::put('/{id}', [BanksController::class, 'updateBank']);
            Route::put('/visible/{id}', [BanksController::class, 'updateVisible']);
            Route::post('/', [BanksController::class, 'createBank']);
            //фильтрация банков
            Route::post('/filter', [BanksController::class, 'banksFilter']);
        });
        //Вывод всех пользователей

        Route::group(['namespace' => 'Users', 'prefix' => 'users'], function () {
            Route::get('/', [UsersController::class, 'allUsers']);
            Route::get('/all', [UsersController::class, 'Users']);
            Route::post('/', [UsersController::class, 'changeUsersRole']);
            Route::delete('/{id}', [UsersController::class, 'deleteUser']);
        });
        //Манипуляции с новостями
        Route::group(['namespace' => 'News', 'prefix' => 'news'], function () {
            Route::get('/', [NewsController::class, 'allNews']);
            Route::post('/addNews', [NewsController::class, 'addNews']);
        });

        //                                                             ::::::::::::::::| Chats |::::::::::::::::
        Route::group(['namespace' => 'Chats', 'prefix' => 'chats'], function () {
            //                              ::::::::::::::::| Groups |::::::::::::::::
            //create new group
            Route::post('/group', [GroupController::class, 'create']);
            //edit group name and users in group
            Route::put('/group', [GroupController::class, 'store']);
            //get all groups
            Route::get('/group', [GroupController::class, 'index']);
            //get users info from groups by group_id
            Route::get('/group/{group_id}', [GroupController::class, 'getUsersInGrouById']);
            //delete group
            Route::delete('/group', [GroupController::class, 'delete']);
            //All Group info For User login         | my groups |   
            Route::get('/groupForUser', [GroupController::class, 'AllGroupForUserlogin']);
            //                              ::::::::::::::::| Messages |::::::::::::::::
            //send meesage to user
            Route::post('/message', [ChatController::class, 'message']);
            //get All Messages for User with another users
            Route::get('/message', [ChatController::class, 'allMessages']);
            //get Messages for User By receiver_id   
            Route::get('/message/{receiver_id}', [ChatController::class, 'index']);
            //send Messaget to Group By group id
            Route::post('/message_group/{group_id}', [ChatController::class, 'messageGroup']);
            // Get all messages for user(me) in group by group_id
            Route::get('/message_group/{group_id}', [ChatController::class, 'indexGroup']);


            //reading meesage from user
            Route::post('/read', [ChatController::class, 'read']);
            //reading meesage from Group By group id
            // Route::post('/read_group', [ChatController::class, 'readGroup']);



            //delete All messages from Group by group id 
            Route::delete('/message_group', [ChatController::class, 'delAllmessagesFromGroup']);
            //delete One message from Group by message id
            Route::delete('/del_message_group', [ChatController::class, 'delOneMessageFromGroup']);

            //delete All messages from user by user id 
            Route::delete('/message', [ChatController::class, 'delAllmessagesFromUser']);
            //delete One message from user by message id
            Route::delete('/del_message', [ChatController::class, 'delOneMessageFromUser']);
        });
        //files
        Route::group(['namespace' => 'Files', 'prefix' => 'files'], function () {
            Route::post('/', [FilesController::class, 'store']);
            Route::get('/', [FilesController::class, 'index']);
        });

        //dashboard
        Route::group(['namespace' => 'Statistics', 'prefix' => 'statistics'], function () {
            // Route::post('/dashboard', [StatisticsController::class, 'dashboard']);
            Route::post('/dashboard', [StatisticsController::class, 'dashboard']);

            Route::post('/addPlan', [StatisticsController::class, 'PlanOfMonth']);
            Route::post('/addResult', [StatisticsController::class, 'ResultsOfDay']);
            

            Route::get('/addPlan', [StatisticsController::class, 'FormForPlanOfMonth']);
            Route::get('/addResult', [StatisticsController::class, 'FormForResultsOfDay']);
            
        });

        Route::group(['namespace'=> 'Departments', 'prefix'=>'depatments'], function(){
            Route::get('/', [DepartmentController::class, 'AllDepartment']);
            Route::get('/form', [DepartmentController::class, 'FormForCreateDepartment']);
            Route::get('/{id}', [DepartmentController::class, 'oneDepartment']);
            Route::post('/{id}/staff', [DepartmentController::class, 'DeleteStaff']);
            Route::post('/{id}/addstaff', [DepartmentController::class, 'AddStaff']);
            Route::post('/build', [DepartmentController::class, 'CreateDepartment']);
         });
    });
});
