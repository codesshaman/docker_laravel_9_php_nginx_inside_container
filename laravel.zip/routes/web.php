<?php

use App\Events\BlockEvent;
use App\Events\GroupChatEvent;
use App\Events\MsgReadEvent;
use App\Events\PrivateChatEvent;
use App\Events\SessionEvent;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


Route::get('/send', function () {
    $chat= array('BMW' => 'Germany');
   return event(new  GroupChatEvent(1,"324" ));
});
 
Route::get('/resetPasswordSuccess', function () {
    return view('auth.reset-password-success');
});
Route::get('/resetPasswordLinkError', function () {
    return view('auth.reset-password-link-error');
});

//////// for testing sockit !
Route::get('/PrivateChatEvent', function () {
    $chat = ['session_id' => 1];
    $content="meeeesage123";
     return event(new  PrivateChatEvent($content, $chat));
});
Route::get('/MsgReadEvent', function () {
     $session_id = 1 ;
    $chat= array('BMW' => 'Germany');
    return event(new  MsgReadEvent($chat, $session_id));
});
Route::get('/BlockEvent', function () {
    $blocked = 0;
    $session_id = 1 ;
    return event(new  BlockEvent($session_id, $blocked));
});
Route::get('/SessionEvent', function () {
    $session_by = 1;
    $session = 23423;
    return event(new  SessionEvent($session, $session_by));
});
