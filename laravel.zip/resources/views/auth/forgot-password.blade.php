<h2>Забыл пароль?</h2>

<div>
    <p>Введите email Для сброса пароля</p>
    <form method="POST" action="{{ route('password.email') }}">
    <input id="email" name="email" type="email" placeholder="email" />
    <br /><br /><br />
    <div>
        <button type="submit">
            Отправить
        </button>
    </div>
</form>
</div>