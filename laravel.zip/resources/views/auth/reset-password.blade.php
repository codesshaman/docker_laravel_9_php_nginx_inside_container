<h2>Восстановление пароля</h2>

@if($errors->any())
    {!! implode('', $errors->all('<font color="red"><h3 color="red">:message</h3></font>')) !!}
@endif

<div>
    <form method="POST" action="{{ route('password.update') }}">
        <input type="hidden" name="token" value="{{ $token }}">
        <input type="hidden" name="email" value="{{ $email }}">
        <p>Введите новый пароль</p>
        <input id="password" name="password" type="text" placeholder="Введите пароль" />
        <p>Подтвердите пароль</p>
        <input id="password_confirmation" name="password_confirmation" type="text" placeholder="Повторите пароль" />
        <br /><br /><br />
        <div>
            <button type="submit">
                Отправить
            </button>
        </div>
    </form>
</div>