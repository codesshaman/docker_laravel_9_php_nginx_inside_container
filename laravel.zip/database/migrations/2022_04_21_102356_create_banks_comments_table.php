<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('banks_comments', function (Blueprint $table) {
            $table->id();
            $table->string('avance_return', 500)->nullable();
            $table->string('exchange', 500)->nullable();
            $table->string('limit_client', 500)->nullable();
            $table->string('limit_bg', 500)->nullable();
            $table->string('limit_month', 500)->nullable();
            $table->string('exec_deadline', 500)->nullable();
            $table->string('go_deadline', 500)->nullable();
            $table->string('bg_size', 500)->nullable();
            $table->string('fraction_collecting', 500)->nullable();
            $table->string('gup_mup', 500)->nullable();
            $table->string('nbki', 500)->nullable();
            $table->string('support', 500)->nullable();
            $table->string('payment', 500)->nullable();
            $table->string('number', 500)->nullable();
            $table->string('resident', 500)->nullable();
            $table->string('caucasian', 500)->nullable();
            $table->string('crimea', 500)->nullable();
            $table->string('overstatement', 500)->nullable();
            $table->string('closed', 500)->nullable();
            $table->string('nmck', 500)->nullable();
            $table->string('losses', 500)->nullable();
            $table->string('p615', 500)->nullable();
            $table->string('kik', 500)->nullable();
            $table->string('kbg', 500)->nullable();
            $table->string('discount', 500)->nullable();
            $table->string('delivery', 500)->nullable();
            $table->string('guarantor', 500)->nullable();
            $table->string('fz_275', 500)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('banks_comments');
    }
};
