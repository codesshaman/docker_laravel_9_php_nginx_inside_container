<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('qualities_months', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users');
            $table->integer('sum_plan')->default(0);
            $table->integer('calls') -> nullable()->default(0);
            $table->integer('long_calls')-> nullable()->default(0);
            $table->integer('balances')-> nullable()->default(0);
            $table->integer('good_balances')-> nullable()->default(0); 
            $table->integer('sum_bg')-> nullable()->default(0);
            $table->integer('sum_issued_bg')-> nullable()->default(0);
            $table->integer('date')-> nullable(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('qualities_months');
    }
};
