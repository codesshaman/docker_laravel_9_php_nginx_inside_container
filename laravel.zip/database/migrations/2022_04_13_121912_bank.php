<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use phpDocumentor\Reflection\PseudoTypes\True_;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('banks', function (Blueprint $table) {
            $table->id();
            $table->string('title', 50);
            $table->text('logo')->nullable();
            $table->boolean('avance_return')->nullable()->default(0);
            $table->boolean('exchange')->nullable()->default(0);
            $table->integer('limit_client')->nullable()->default(0);
            $table->integer('limit_bg')->nullable()->default(0);
            $table->integer('limit_month')->nullable()->default(0);
            $table->integer('exec_deadline')->nullable()->default(0);
            $table->integer('go_deadline')->nullable()->default(0);
            $table->integer('bg_size')->nullable()->default(0);
            $table->boolean('fraction_collecting')->nullable()->default(0);
            $table->boolean('gup_mup')->nullable()->default(0);
            $table->boolean('nbki')->nullable()->default(0);
            $table->boolean('support')->nullable()->default(0);
            $table->boolean('payment')->nullable()->default(0);
            $table->boolean('number')->nullable()->default(0);
            $table->boolean('resident')->nullable()->default(0);
            $table->boolean('caucasian')->nullable()->default(0);
            $table->boolean('crimea')->nullable()->default(0);
            $table->string('overstatement', 100)->nullable()->default('0');
            $table->boolean('closed')->nullable()->default(0);
            $table->boolean('nmck')->nullable()->default(0);
            $table->boolean('losses')->nullable()->default(0);
            $table->boolean('p615')->nullable()->default(0);
            $table->boolean('kik')->nullable()->default(0);
            $table->boolean('kbg')->nullable()->default(0);
            $table->boolean('discount')->nullable()->default(0);
            $table->boolean('delivery')->nullable()->default(0);
            $table->boolean('guarantor')->nullable()->default(0);
            $table->boolean('fz_275')->nullable()->default(0);
            $table->timestamp('changing_date');
            $table->boolean('visible')->default(1);
            
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
};
