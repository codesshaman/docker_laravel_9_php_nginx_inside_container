<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;

class BanksCommentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $array = [Str::random(rand(5,10)) . ' ' . Str::random(rand(10,15)). ' ' . Str::random(rand(5,10)),NULL,Str::random(rand(3,20))];
        DB::table('banks_comments')->insert([
            'avance_return' => $array[array_rand($array, 1)],
            'exchange' => $array[array_rand($array, 1)],
            'limit_client' =>$array[array_rand($array, 1)],
            'limit_bg' => $array[array_rand($array, 1)],
            'limit_month' => $array[array_rand($array, 1)],
            'exec_deadline' => $array[array_rand($array, 1)],
            'go_deadline' => $array[array_rand($array, 1)],
            'bg_size' => $array[array_rand($array, 1)],
            'fraction_collecting' => $array[array_rand($array, 1)],
            'gup_mup' => $array[array_rand($array, 1)],
            'nbki' => $array[array_rand($array, 1)],
            'support' =>$array[array_rand($array, 1)],
            'payment' => $array[array_rand($array, 1)],
            'number' => $array[array_rand($array, 1)],
            'resident' => $array[array_rand($array, 1)],
            'caucasian' => $array[array_rand($array, 1)],
            'crimea' => $array[array_rand($array, 1)],
            'overstatement' => $array[array_rand($array, 1)],
            'closed' => $array[array_rand($array, 1)],
            'nmck' => $array[array_rand($array, 1)],
            'losses' => $array[array_rand($array, 1)],
            'p615' => $array[array_rand($array, 1)],
            'kik' => $array[array_rand($array, 1)],
            'kbg' => $array[array_rand($array, 1)],
            'discount' => $array[array_rand($array, 1)],
            'delivery' => $array[array_rand($array, 1)],
            'guarantor' => $array[array_rand($array, 1)],
            'fz_275' => $array[array_rand($array, 1)],
        ]
        );

    }
        
}
