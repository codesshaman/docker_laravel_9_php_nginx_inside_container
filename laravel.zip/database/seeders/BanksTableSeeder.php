<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class BanksTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {   $overs = ['запрещено','x2','x3','x5'];
        DB::table('banks')->insert([
            'title' =>  Str::random(7),
            'logo' => Str::random(10),
            'avance_return' => rand(1,0),
            'exchange' => rand(1,0),
            'limit_client' => rand(10000,10000000),
            'limit_bg' => rand(100000, 1000000),
            'limit_month' => rand(1,1500),
            'exec_deadline' => rand(1,100),
            'go_deadline' => rand(1,100),
            'bg_size' => rand(100000, 1000000),
            'fraction_collecting' => rand(1,0),
            'gup_mup' => rand(1,0),
            'nbki' => rand(1,0),
            'support' => rand(1,0),
            'payment' => rand(1,0),
            'number' => rand(1,0),
            'resident' => rand(1,0),
            'caucasian' => rand(1,0),
            'crimea' => rand(1,0),
            'overstatement' => $overs[array_rand($overs, 1)],
            'closed' => rand(1,0),
            'nmck' => rand(1,0),
            'losses' => rand(1,0),
            'p615' => rand(1,0),
            'kik' => rand(1,0),
            'kbg' => rand(1,0),
            'discount' => rand(1,0),
            'delivery' => rand(1,0),
            'guarantor' => rand(1,0),
            'fz_275' => rand(1,0),
            'changing_date' => rand(2020, 2022) . '-' . rand(1, 12) . '-' . rand(1, 28) . ' ' .  rand(8, 17) . ':' .  rand(20, 55) . ':' .  rand(20, 55),
        ]
        );
    }
}
